package controleur;

import static modele.Deplacement.AVANCER;
import static modele.Deplacement.DROITE;
import static modele.Deplacement.GAUCHE;
import static modele.Deplacement.RECULER;
import static modele.Deplacement.STOP;

import java.awt.geom.Point2D;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JOptionPane;

import org.lwjgl.input.Controller;

import communication.WifiComm;
import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import debug.WallE_Logger;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import manette_support.Commandes;
import manette_support.ListeManettes;
import manette_support.MappageManetteAUTRE;
import modele.Deplacement;
import modele.LabyrintheDePledge;
import modele.ModeleWallE;
import modele.WallE_Utilitaire;
import vue.VueAuto;
import vue.VueChoixIP;
import vue.VueManuel;
import vue.VueParent;
import vue.VueWelcome;

/**
 * Le Contrôleur principal de l'application est le relais entrte la vue et le
 * modèle. S'occupe de faire des tâches simples où d'evoyer les tâches plus
 * complexes vers le modèle.
 *
 * @author Los Santos Customs
 *
 */
public class ControleurWallE {

	/**
	 * La vue de l'application
	 */
	private VueParent vue;

	/**
	 * Le modèle utilisé pour les opérations de l'application
	 *
	 * @param stage
	 */
	private ModeleWallE modele;

	/**
	 * La connection entre le robot et l'application
	 */
	private WifiComm connection;

	/**
	 * L'évenement temporaire en mémoire pour retenir certaines informations pour
	 * plus tard
	 */
	public Event tempEvent;

	/**
	 * La manette en utilisation par l'utilisateur, s'il y a lieu
	 */
	private Commandes manette;

	/**
	 * Écouteur sur la manette de l'utilisateur, si elle est connectée
	 */
	ChangeListener<Object[]> controllerListener;

	/**
	 * Le dépalcement du robot demandé par la manette où le clavier
	 */
	private Point2D deplacementManette;

	/**
	 * Le dépalcement de la caméra demandé par la manette où le clavier
	 */
	private Point2D camera;

	/**
	 * La vitesse à laquelle la voiture doit avancer, min 0 et max 100
	 * (x,y)-->(roues gauches, roues droites)
	 */
	private Point2D vitesse;

	/**
	 * S'occupe de déterminer si le clavier est en contrôle où non
	 */
	private boolean controleClavier;

	private WallE_Logger logView;

	private VueParent vueBackup;

	private LabyrintheDePledge AI_autonome;

	private ChangeListener<Number> AI_Listener;

	/**
	 * Constructeur du contrôleur de l'Application : Est fait aussitôt que
	 * l'application se lance. Un seul contrôleur sera utilisé : Il sera passé de
	 * vue en vue au fur et à mesure qu'on change d'interface. S'occupe de lancer
	 * l'écran d'accueil, la connection est créée. Créée également la manette, le
	 * modèle et l'écouteur pour la manette
	 *
	 * @param stage - La fenêtre de l'application
	 */
	public ControleurWallE(Stage stage) {

		this.logView = new WallE_Logger();
		this.modele = new ModeleWallE();
		this.AI_autonome = new LabyrintheDePledge(this.modele);
		this.AIinstructionListener();
		this.vue = new VueWelcome(stage, this);

		this.controleClavier = true;
		this.manette = new Commandes();
		this.controllerListener = this.manetteChangeListener();

		this.deplacementManette = new Point2D.Double();
		this.vitesse = new Point2D.Double();
		this.camera = new Point2D.Double();
		this.setVitesseDefaut();
		this.chocListener();
		this.immobileDetection();
	}

	public void activerInterfaceUpdate() {

		if (this.vue instanceof VueManuel || this.vue instanceof VueAuto) {
			this.vue.getLblVitesse().textProperty().bind(this.modele.getVitesse_Lbl());
			this.vue.getLblObstacle().textProperty().bind(this.modele.getObstacleProche_Lbl());
			this.vue.getLblCinetique().textProperty().bind(this.modele.getCinetique_Lbl());

			if (this.vue instanceof VueAuto) {
				((VueAuto) this.vue).getLblPositionX().textProperty().bind(this.modele.getPosX_Lbl());
				((VueAuto) this.vue).getLblPositionY().textProperty().bind(this.modele.getPosY_Lbl());
			}

			else if (this.vue instanceof VueManuel)
				((VueManuel) this.vue).getLblTempsImpact().textProperty().bind(this.modele.getTempsImpact_Lbl());
		}
	}

	/**
	 * Instancie l'écouteur qui servira à receptionner et gerer les demandes de l'AI
	 * (deplacement)
	 */
	private void AIinstructionListener() {

		this.AI_Listener = (observable, oldValue, newValue) -> Platform.runLater(() -> {
			if (newValue.intValue() == 1)
				ControleurWallE.this.transmit(AVANCER, WifiComm.CONTROLE_FLAG);
			else if (newValue.intValue() == 0)
				ControleurWallE.this.transmit(STOP, WifiComm.CONTROLE_FLAG);
			else if (newValue.intValue() == -1)
				ControleurWallE.this.transmit(RECULER, WifiComm.CONTROLE_FLAG);
			else if (newValue.intValue() == LabyrintheDePledge.AI_ERROR)
				ControleurWallE.this.logView.logErreur(new WallE_Exception("L'auto est coincé, arrêt de l'AI...",
						WallE_ErrorLevel.ERREUR_FATALE, LocalDateTime.now()));
			else if (ControleurWallE.this.AI_autonome.getAngleRotation() > 0)
				ControleurWallE.this.transmit(GAUCHE, WifiComm.CONTROLE_FLAG);
			else
				ControleurWallE.this.transmit(DROITE, WifiComm.CONTROLE_FLAG);
		});
	}

	public void alerterAutoModeChange() {
		this.transmit(STOP, WifiComm.MODE_CHANGEMENT_FLAG);
	}

	public void backupDestruction() {
		this.vueBackup = null;
	}

	public void backupLoad() {
		if (this.vueBackup instanceof VueAuto) {
			((VueAuto) this.vueBackup).loadVue();
			this.vue = this.vueBackup;
			this.setLogger(this.vue.getTxtFL_log());
		} else if (this.vueBackup instanceof VueManuel) {
			((VueManuel) this.vueBackup).loadVue();
			this.vue = this.vueBackup;
			this.setLogger(this.vue.getTxtFL_log());
		} else if (this.vueBackup instanceof VueWelcome) {
			((VueWelcome) this.vueBackup).loadVue();
			this.vue = this.vueBackup;
		}
	}

	public void backupVue() {
		this.vueBackup = this.vue;
	}

	public void chargerStream() {
		try {
			if (this.vue instanceof VueManuel || this.vue instanceof VueAuto)
				this.vue.startStream(JOptionPane.showInputDialog("Entrez le lien du stream de la video"));
		} catch (WallE_Exception e) {
			this.logView.logErreur(e);
		}
	}

	private void chocListener() {
		this.modele.getChoc().addListener((ChangeListener<Boolean>) (observable, oldValue, newValue) -> {
			if (newValue) {

				ControleurWallE.this.transmit(STOP, WifiComm.CONTROLE_FLAG);
				Platform.runLater(() -> {
					ControleurWallE.this.logView
							.logErreur(new WallE_Exception(
									"Arrêt d'urgence, obstacle devant à "
											+ ControleurWallE.this.modele.distanceCapteurAvant() + " cm",
									WallE_ErrorLevel.ERREUR_FATALE, LocalDateTime.now()));
				});
				ControleurWallE.this.modele.setVitesse(0);
			}

		});
	}

	/**
	 * Méthode qui est appellée quand un utilisateur entre en collision avec un
	 * objet. Va retourner sur l'interface la force de collision avec l'objet en
	 * Newtons
	 *
	 * @param b - True si l'utilisateur déclare une collision
	 */
	public void collision(boolean b) {
		((VueManuel) this.vue).getLblForceCollision()
				.setText("" + this.modele.collisionneur(this.modele.getChrono().getDureeSec()));
	}

	/**
	 * detecte la reception d'information provenant de la voiture et les partage
	 * vers le reste de l'application
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void connectionAlerteReception() {
		this.connection.getBuffer().addListener((ListChangeListener) c -> {

			if (this.connection.isReceptionFinie() && c.getList().size() == WifiComm.RECEIVE_BUFFER_SIZE) {
				ArrayList<Integer> temp = new ArrayList();
				temp.addAll(c.getList());
				this.modele.update_Cap_DisPar(temp);

				temp.get(0);
				temp.get(1);
				temp.get(2);
				Platform.runLater(() -> {
//					logView.logDonnees(Arrays.toString(clone));
//					logView.logDonnees(
//							"DSA : " + modele.getDisantceSegmentActuel() + "DPT :" + modele.getDisParTotale());
				});
			}
		});
	}

	/**
	 * Déconnecte complètement l'application du serveur de l'auto
	 */
	public void connectionFermer() {
		if (this.connection != null) {
			if (this.connection.verifierConnection())
				this.transmit(STOP, WifiComm.MODE_CHANGEMENT_FLAG);
			if (!this.connection.deconnection())
				JOptionPane.showMessageDialog(null, "Un probleme empêche la déconnection du serveur",
						"Erreur de deconnection", JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * S'occupe d'initialiser la connection, demande si on utilise les pramètres par
	 * défaut. Si oui, on lance la connexion avec les paramètres par défaut. Si non,
	 * on essaie de lancer une connection au robot avec les données entrées par
	 * l'utilisateur
	 *
	 * @param paramDefaut - True si on utilise les paramètres par défaut
	 * @return true si la connection est active
	 */
	public boolean connexionConfirmer(boolean paramDefaut) {

		boolean connected = false;
		if (this.vue instanceof VueChoixIP && !paramDefaut) {

			VueChoixIP vueTemp = (VueChoixIP) this.vue;

			// met les données reçues dans le format adéquat
			int port = !vueTemp.txtFieldPort.getText().isEmpty() ? Integer.parseInt(vueTemp.txtFieldPort.getText())
					: -1;
			String ipAdress = vueTemp.txtFieldIP1.getText() + "." + vueTemp.txtFieldIP2.getText() + "."
					+ vueTemp.txtFieldIP3.getText() + "." + vueTemp.txtFieldIP4.getText();

			// vérifie le format des données rentrées avant d'initier la connection
			if (ipAdress.length() > WifiComm.MIN_IPFORMAT_LENTGH && ipAdress.length() <= WifiComm.MAX_IPFORMAT_LENTGH
					&& port <= WifiComm.MAX_PORT_NBR && port > WifiComm.MIN_PORT_NBR) {

				this.connection = new WifiComm(ipAdress, port);
				this.connectionAlerteReception();
				connected = this.connection.initConnection();

			} else
				JOptionPane.showMessageDialog(null,
						"Erreur avec les informations entrées, veuillez rentrer une adresse IP et un port valide",
						"Erreur avec les informations", JOptionPane.INFORMATION_MESSAGE);
		} else {
			this.connection = new WifiComm();
			this.connectionAlerteReception();
			connected = this.connection.initConnection();
		}
		return connected;
	}

	/**
	 * Vérifie si la connexion est active, si non, affiche une nouvelle demande de
	 * connexion connexion
	 */
	public void connexionVerifier() {
		if (this.connection != null && this.connection.verifierConnection())
			System.out.println("Connection Active");
		else
			new VueChoixIP(this.vue.getStage(), this.vue.getControleur());
	}

	/**
	 * Donne le contrôle à la sélection de l'utilisateur, que ce soit une manette ou
	 * un clavier
	 *
	 * @param selection - Le périphérique sélectionné par l'utilisateur
	 * @throws Exception
	 */
	public void controle(String selection) throws Exception {

		if (selection != null)
			if (selection.equalsIgnoreCase(ListeManettes.options[0])) {
				if (this.manette.isManetteConnectee()) {
					this.stopManette();
					this.manette.getManette().getData_link().removeListener(this.controllerListener);
					this.manette.detruireManette();
				}

				this.deplacementManette.setLocation(0, 0);
				this.controleClavier = true;
				this.setVitesseDefaut();

			} else if (this.manette.getListManette().containsKey(selection))
				try {

					if (this.manette.isManetteConnectee()) {
						this.stopManette();
						this.manette.getManette().getData_link().removeListener(this.controllerListener);
						this.manette.detruireManette();
					}
					this.manette.setSelection(this.manette.getListManette().get(selection));
					this.manette.connecterManette();
					this.manette.getManette().getData_link().addListener(this.controllerListener);
					this.controleClavier = false;
					this.startManette();
				} catch (WallE_Exception exception) {
					this.logView.logErreur(exception);
					throw new Exception();
				}
			else if (this.manette.getListNonsupportees().contains(selection)) {
				// TODO manette non supporter a rajouter
			}

	}

	public void desactiverInterfaceUpdate() {

		if (this.vue instanceof VueManuel || this.vue instanceof VueAuto) {
			this.vue.getLblVitesse().textProperty().unbind();
			this.vue.getLblObstacle().textProperty().unbind();
			this.vue.getLblCinetique().textProperty().unbind();

			if (this.vue instanceof VueAuto) {
				((VueAuto) this.vue).getLblPositionX().textProperty().unbind();
				((VueAuto) this.vue).getLblPositionY().textProperty().unbind();
			} else if (this.vue instanceof VueManuel)
				((VueManuel) this.vue).getLblTempsImpact().textProperty().unbind();
		}
	}

	/**
	 * Retourne une liste de tous les périphériques connectés à l'ordinateur qui ne
	 * sont pas supportés par l'application
	 *
	 * @return Les périphériques connectés à l'ordinateur
	 */
	public List<String> getListeManettesNonSupporte() {
		return this.manette.getListNonsupportees();
	}

	/**
	 * Retourne une Liste des manettes qui sont supportées par le système
	 *
	 * @return une liste de manettes supportées par le système
	 */
	public List<String> getListeManettesSupporte() {
		return new ArrayList<>(this.manette.getListManette().keySet());
	}

	public WallE_Logger getLogView() {
		return this.logView;
	}

	/**
	 * Retourne la scène de l'application
	 *
	 * @return Scene - la scène de l'application
	 */
	public Scene getScene() {
		return this.vue.getScene();
	}

	/**
	 * Retourne la vue ouverte actuellement
	 *
	 * @return la vue du parent
	 */
	public VueParent getVue() {
		return this.vue;
	}

	private void immobileDetection() {
		this.modele.isImmobile().addListener((ChangeListener<Boolean>) (observable, oldValue, newValue) -> {
			if (newValue)
				ControleurWallE.this.modele.cancel();
			else if (!newValue && !ControleurWallE.this.modele.isRunning())
				ControleurWallE.this.modele.restart();

		});
	}

	/**
	 * Méthode qui s'occupe de s'assurer que la manette est connectée au système
	 *
	 * @return True si la manette est connectée à l'application
	 */
	public boolean isManetteConnected() {
		return this.manette.isManetteConnectee();
	}

	/**
	 * ceer l'ecouteur qui permet de detecter une action effectuee par la manette et
	 * de lancer la gestion de cette action
	 *
	 * @return un ecouteur sur la manette branche (s'il y'en a une)
	 */
	private ChangeListener<Object[]> manetteChangeListener() {

		// reception des commandes de manettes et lancement du traitement de ceux-ci
		return (observable, oldValue, newValue) -> {
			this.deplacementManette = (Point2D) newValue[0];
			this.camera = (Point2D) newValue[1];

			this.vitesse.setLocation(
					this.deplacementManette.getX() < 0 ? WallE_Utilitaire.virageVitesse(this.deplacementManette)
							: WallE_Utilitaire.multiplierCent(Math.abs(this.deplacementManette.getY())),
					this.deplacementManette.getX() > 0 ? WallE_Utilitaire.virageVitesse(this.deplacementManette)
							: WallE_Utilitaire.multiplierCent(Math.abs(this.deplacementManette.getY())));

			Platform.runLater(() -> {
				this.modele
						.setVitesse(WallE_Utilitaire.vitesseTOcmPs(Math.min(this.vitesse.getX(), this.vitesse.getY())));
			});
			this.mouvement(new ActionEvent());
		};
	}

	/**
	 * LAnce le mappage d'une nouvelle manette non actuellement supporté par le
	 * système
	 *
	 * @param selectedItem - L'item sélectionné dans la liste de périphériques
	 *                     connectés
	 */
	public void manetteConfig(String selectedItem) {
		for (Controller device : ListeManettes.devices)
			if (device.getName().equals(selectedItem))
				new MappageManetteAUTRE(device);

	}

	/**
	 * demande à l'utilisateur d'entrer un message à envoyer au robot
	 *
	 * @param event Le clic de l'utilisateur sur l'option d'envoi de messages au
	 *              robot
	 * @return le message entré par l'utilisateur s'il est valide ou un message
	 *         "ERREUR!!!" dans le cas contraire
	 */
	public String message(Event event) {
		this.logView.logDonnees("envoie de message vers la voiture");
		String message = JOptionPane.showInputDialog("Faites afficher le message de votre choix!" + "Entrer ici",
				"-- Votre Message --");

		if (message != null && message.length() <= WallE_Utilitaire.MESSAGE_MAX_CARACTERE)
			try {
				int[] buffer = new int[message.getBytes().length + 1];
				WallE_Utilitaire.prepareMessage(buffer, message.getBytes(StandardCharsets.UTF_8));
				this.logView.logDonnees(Arrays.toString(message.getBytes(StandardCharsets.UTF_8)));
				this.logView.logDonnees(Arrays.toString(buffer));
				this.connection.transmit(buffer);
			} catch (WallE_Exception e) {
				this.logView.logErreur(new WallE_Exception("Problème d'envoie du message, veuillez ressayer",
						WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now()));
			}
		else {
			message = "ERREUR!!";
			this.logView
					.logErreur(
							new WallE_Exception(
									"Message trop long, il ne doit pas dépacer "
											+ WallE_Utilitaire.MESSAGE_MAX_CARACTERE + "  caractères",
									WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now()));
		}
		return message;

	}

	/**
	 * Méthode qui s'occupe de transmettre les commandes de direction de
	 * l'utilisateur vers le robot
	 *
	 * @param event - Le clic de l'utilisateur, s'il clique sur une des options sur
	 *              l'interface directement
	 *
	 */
	public void mouvement(Event event) {

		String move = "";
		if (this.controleClavier)
			if (event.getSource() instanceof Button)
				move = ((Button) event.getSource()).getText();

		if (move.equalsIgnoreCase(AVANCER.getMoveClavier()) || this.deplacementManette.getY() > 0) {
			if (!this.modele.getChoc().getValue().booleanValue()) {
				if (this.controleClavier)
					this.modele.setVitesse(WallE_Utilitaire.VITESSE_MAX_CM_PAR_S);
				this.transmit(AVANCER, WifiComm.CONTROLE_FLAG);
			}
		}

		else if (move.equalsIgnoreCase(RECULER.getMoveClavier()) || this.deplacementManette.getY() < 0) {
			if (this.controleClavier)
				this.modele.setVitesse(WallE_Utilitaire.VITESSE_MAX_CM_PAR_S);
			this.transmit(RECULER, WifiComm.CONTROLE_FLAG);
		}

		else if (move.equalsIgnoreCase(DROITE.getMoveClavier())) {
			if (this.controleClavier)
				this.modele.setVitesse(WallE_Utilitaire.VITESSE_MAX_CM_PAR_S);
			this.transmit(DROITE, WifiComm.CONTROLE_FLAG);
		}

		else if (move.equalsIgnoreCase(GAUCHE.getMoveClavier())) {
			if (this.controleClavier)
				this.modele.setVitesse(WallE_Utilitaire.VITESSE_MAX_CM_PAR_S);
			this.transmit(GAUCHE, WifiComm.CONTROLE_FLAG);
		}

		else {
			if (this.controleClavier)
				this.modele.setVitesse(WallE_Utilitaire.VITESSE_MIN);
			this.transmit(STOP, WifiComm.CONTROLE_FLAG);
		}

	}

	public void resetInterface() {
		this.modele.RecommencerModele();
	}

	/**
	 * Lance la commande detection de périphériques, pour avoir la liste de
	 * péruphériques connectés au système
	 */
	public void runDevicesDetection() {
		this.manette.detectConnectedComponents();
	}

	public void setAI_Destination(int x, int y) {
		this.AI_autonome.setObjectif(x, y);
	}

	public void setLogger(TextFlow log) {
		this.logView.changerLog(log);
	}

	private void setVitesseDefaut() {
		this.vitesse.setLocation(WallE_Utilitaire.VITESSE_DEFAUT, WallE_Utilitaire.VITESSE_DEFAUT);
		this.modele.setVitesse(0);
	}

	/**
	 * Conserve en mémoire le pointeur de la vue actuelle
	 *
	 * @param vue - la vue actuelle
	 */
	public void setVue(VueParent vue) {
		this.vue = vue;
	}

	public void startAI_autonome() {
		this.stopAI_autonome();
		this.modele.resetPos();
		this.AI_autonome.getInfoMouvement().addListener(this.AI_Listener);
		this.AI_autonome.restart();
	}

	public void startManette() {
		if (this.manette.isManetteConnectee())
			this.manette.restart();
	}

	public void startModele() {
		this.modele.restart();
	}

	public void stopAI_autonome() {
		this.AI_autonome.cancel();
		this.AI_autonome.getInfoMouvement().removeListener(this.AI_Listener);
	}

	public void stopManette() {
		this.manette.cancel();
	}

	public void stopModele() {
		this.modele.cancel();
	}

	public void stopResumeLog() {
		this.logView.stopLog();
	}

	/**
	 * réunis les infos de controle nécessaires pour ensuite les envoyer vers l'auto
	 *
	 * paramètre du buffer : { type d'info envoyé - mode de conduite -commande
	 * (direction) - vitesse roues gauches - vitesse roues droites - (angle1 camera
	 * - angle2 camera) ou (angle de virage 1 - angle de virage 2}
	 *
	 *
	 * @param deplacement direction dans laquelle l'auto devra se déplacer
	 * @param typeInfos   type d'info envoyé (info de controle - alerte de
	 *                    changement de mode - message texte à afficher)
	 */
	private void transmit(Deplacement deplacement, int typeInfos) {

		try {
			int[] buffer = new int[WifiComm.TRANSMISSION_BUFFER_SIZE];

			buffer[0] = typeInfos; // type d'info envoyé
			buffer[1] = deplacement.getCommande(); // direction du depacement
			buffer[2] = (int) this.vitesse.getX(); // vitesse roues gauches
			buffer[3] = (int) this.vitesse.getY(); // vitesse roues droites
			buffer[4] = (int) this.camera.getX(); // angle horizontal de la camera
			buffer[5] = (int) this.camera.getY(); // angle vertical de la camera

			if (this.connection != null)
				this.connection.transmit(buffer);
		} catch (WallE_Exception exception) {
			this.logView.logErreur(exception);
		}
	}
}