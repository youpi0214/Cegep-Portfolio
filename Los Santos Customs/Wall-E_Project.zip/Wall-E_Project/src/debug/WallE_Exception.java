package debug;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class WallE_Exception extends Exception {

	private static final long serialVersionUID = -3153607671294423719L;

	private final DateTimeFormatter DATE_HEURE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	private WallE_ErrorLevel errorLevel;
	private LocalDateTime timestamp;
	private String message;

	public WallE_Exception() {
		this("erreur inconnue!", WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now());
	}

	public WallE_Exception(String pMessage, WallE_ErrorLevel level, LocalDateTime pTimeStamp) {
		super(pMessage);
		this.message = pMessage;
		this.errorLevel = level;
		this.timestamp = pTimeStamp;
	}

	public WallE_ErrorLevel getErrorLevel() {
		return this.errorLevel;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	public String getText() {
		return this.getTimestamp() + " -- [" + this.getErrorLevel().toString() + "] " + this.getMessage();
	}

	public String getTimestamp() {
		return this.timestamp.format(this.DATE_HEURE_FORMAT);
	}

	@Override
	public String toString() {

		return this.getText();
	}

}
