package debug;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

/**
 * Classe permettant de faire le suivi des évènement de l'application, tant pour
 * le programmeur que l'utilisateur
 *
 * @author Los Santos Customs
 *
 */
public class WallE_Logger {

	/**
	 * couleur par défaut des messages affichés
	 */
	private final Color DEFAULT_TEXT_COLOR = Color.GREEN;
	private final int FONT_SIZE = 15;
	private final String FONT = "Times New Roman";
	private TextFlow logger;
	private boolean stopLog;
	private List<Text> errorDonneesStack;
	private boolean vidangeEncours;

	public WallE_Logger() {
		this.stopLog = false;
		this.errorDonneesStack = new ArrayList<>();
		this.vidangeEncours = false;
	}

	private void afficherSurLog(Text text) {

		if (this.logger != null && !this.stopLog) {
			if (!this.vidangeEncours && !this.errorDonneesStack.isEmpty()) {
				this.emptyErrorStack();
				this.vidangeEncours = false;
			}
			this.logger.getChildren().addAll(text);
		} else
			this.errorDonneesStack.add(text);
	}

	public void changerLog(TextFlow pLogger) {
		this.logger = pLogger;
	}

	private void emptyErrorStack() {
		this.vidangeEncours = true;
		ListIterator<Text> iter = this.errorDonneesStack.listIterator();
		while (iter.hasNext()) {
			this.afficherSurLog(iter.next());
			iter.remove();
		}
	}

	public void logDonnees(String message) {
		if (!this.stopLog) {
			Text donnees = new Text(message + "\n");
			donnees.setFont(Font.font(this.FONT, this.FONT_SIZE));
			donnees.setFill(this.DEFAULT_TEXT_COLOR);
			this.afficherSurLog(donnees);
		}
	}

	public void logErreur(WallE_Exception erreur) {

		if (!this.stopLog) {
			Text text = new Text(erreur.getText() + "\n");
			text.setFont(Font.font(this.FONT, this.FONT_SIZE));
			text.setFill(erreur.getErrorLevel().getCouleur());
			this.afficherSurLog(text);
		}

	}

	public void stopLog() {
		this.stopLog = !this.stopLog;
	}

}
