package debug;

import java.util.logging.Level;

import javafx.scene.paint.Color;

public enum WallE_ErrorLevel {

	AVERTISSEMENT(Level.WARNING, Color.ORANGE), ERREUR_FATALE(Level.SEVERE, Color.RED), INFO(Level.INFO, Color.BLUE);

	private Level level;
	private Color couleur;

	private WallE_ErrorLevel(Level plevel, Color pCouleur) {
		this.level = plevel;
		this.couleur = pCouleur;
	}

	public Color getCouleur() {
		return this.couleur;
	}

	public Level getLevel() {
		return this.level;
	}

	@Override
	public String toString() {
		return this.level.toString();
	}

}
