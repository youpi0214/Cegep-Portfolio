package communication;

import debug.WallE_Exception;

/**
 * interface determinant les attributs par défaut d'un Objet gestionnaire de
 * connection
 *
 * @author Los Santos Customs
 *
 */
interface Connection {

	/**
	 * Adresse ip par défaut
	 */
	String DEFAULT_IP = "192.168.1.1";

	/**
	 * adresse primaire du stream video de l'auto
	 */
	String VIDEO_URL = "http://192.168.1.1:8080/?action=stream";

	/**
	 * Port de connection par défaut 2001
	 */
	int DEFAULT_PORT_NUMBER = 2001;
	/**
	 * valeur maximal que peut avoir un port de connection 65535
	 */
	int MAX_PORT_NBR = 0xffff;
	/**
	 * valeur minimal que peut avoir un port de connection
	 */
	int MIN_PORT_NBR = 0;
	/**
	 * longeur maximal du format d'une adresse ip
	 */
	int MAX_IPFORMAT_LENTGH = 15;
	/**
	 * longeur minimal du format d'une adresse ip
	 */
	int MIN_IPFORMAT_LENTGH = 3;
	/**
	 * valeur 255 en hexadecimal, elle sert d'alerte pour marquer le début ou la fin
	 * d'une série de données
	 */
	int COMMAND_FLAG = 0xff;

	/**
	 * Utiliser lors de la transmission de données. Envoyé une première fois, il
	 * annonce le début d'une série de commande, puis la deuxième fois, marque la
	 * fin de la commande
	 */
	int COMMAND_INIT = 0xff;

	/**
	 * taille du stockeur temporaire pour la reception de donnees
	 */
	int RECEIVE_BUFFER_SIZE = 7;

	/**
	 * taille du stockeur temporaire pour la transmission de donnees
	 */
	int TRANSMISSION_BUFFER_SIZE = 6;

	/*
	 * Instruction signifiant l'envoie d'information de controle
	 */
	int CONTROLE_FLAG = 155;

	/*
	 * Instruction levant l'alerte d'un changement de mode
	 */
	int MODE_CHANGEMENT_FLAG = 156;

	/*
	 * Instruction signifiant l'envoie dun message texte
	 */
	int MESSAGE_FLAG = 157;

	boolean deconnection();

	boolean initConnection() throws WallE_Exception;

	/**
	 * intercepte les données envoyées venant du serveur auquel cette classe est
	 * connectée
	 *
	 * @throws WallE_Exception
	 *
	 * @throws Exception       erreur lancé lors de la déconnection subite du
	 *                         servueur
	 */
	void receive() throws WallE_Exception;

	/**
	 * Transmetteur de données vers le serveur auquel cette classe est connectée
	 *
	 * @throws WallE_Exception
	 */
	void transmit(int[] data) throws WallE_Exception;

	/**
	 * vérifie si une connection au serveur est existante et si celle-ci est active
	 *
	 * @return si la connection est encore en place et active
	 */
	boolean verifierConnection();
}
