package communication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDateTime;
import java.util.Date;

import javax.imageio.ImageIO;

import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Classe VideoRender, régit l'affichage du stream vidéo de la voiture ainsi que
 * la connexion avec ce dernier.
 *
 * @author Los Santos Customs
 *
 */
public class VideoRender extends Service<Void> implements Connection {

	private static final String CONTENT_LENGTH = "Content-Length: ";
	private URL url;
	private ImageView afficheur;
	private BufferedImage frame;
	private URLConnection urlConn;
	private InputStream urlStream;
	private boolean connectionEtabli;

	/**
	 * ratio prédéfini de l'afficheur {Width,Height}
	 */
	private double[] ratio;

	/**
	 * layout prédéfini de l'afficheur {x,y}
	 */
	private double[] layout;

	/**
	 * Constructeur de la classe VideoRender, instancie l'afficheur et définit le
	 * ratio et le layout de ce dernier.
	 *
	 * @param pViewer
	 */
	public VideoRender(ImageView pViewer) {
		this.connectionEtabli = false;
		this.ratio = new double[2];
		this.layout = new double[2];
		this.afficheur = pViewer;
		this.ratio[0] = this.afficheur.getFitWidth();
		this.ratio[1] = this.afficheur.getFitHeight();
		this.layout[0] = this.afficheur.getLayoutX();
		this.layout[1] = this.afficheur.getLayoutY();
	}

	/**
	 * Reconstruit l'image passée en parametre et lui ajoute la date actuelle.
	 *
	 * @param frame : l'image sur laquelle on veut ajouter la date.
	 */
	private void addTimestampToFrame(BufferedImage frame) {
		Graphics2D g2d = (Graphics2D) frame.getGraphics().create();
		try {
			g2d.setColor(Color.WHITE);
			g2d.drawString(new Date().toString(), 10, frame.getHeight() - 25);
		} finally {
			g2d.dispose();
		}
	}

	/**
	 * Création d'un Task
	 */
	@Override
	protected Task<Void> createTask() {
		return new Task<Void>() {

			@Override
			protected Void call() throws Exception {
				if (!VideoRender.this.connectionEtabli)
					VideoRender.this.initConnection();
				VideoRender.this.receive();
				return null;
			}
		};
	}

	/**
	 * Permet de fermer le stream vidéo et de supprimer la connexion préalablement
	 * établie.
	 *
	 * @return : connectionEtabli, false si la connexion a été supprimée
	 */
	@Override
	public boolean deconnection() {
		// close streams
		try {
			if (this.connectionEtabli) {
				this.cancel();
				this.urlStream.close();
				this.connectionEtabli = false;
			}
		} catch (IOException ioe) {
			System.err.println("Failed to close the stream: " + ioe);
		}
		return this.connectionEtabli;
	}

	/**
	 * Permet d'initialiser la connexion avec le stream vidéo.
	 *
	 * @return : connectionEtabli, true si la connexion est réussie
	 */
	@Override
	public boolean initConnection() throws WallE_Exception {
		try {
			this.urlConn = this.url.openConnection();
			this.urlConn.setReadTimeout(5000);
			this.urlConn.connect();
			this.urlStream = this.urlConn.getInputStream();
			this.connectionEtabli = true;
		} catch (IOException e) {
			this.afficheur
					.setImage(new Image("images/connectionEchec.png", this.ratio[0], this.ratio[1], false, false));
			throw new WallE_Exception("connection au server video HTTP echouée", WallE_ErrorLevel.ERREUR_FATALE,
					LocalDateTime.now());
		}

		return this.connectionEtabli;
	}

	/**
	 * Intercepte les données envoyées par le stream vidéo, puis recrée l'image
	 * originale dans l'afficheur de la classe.
	 */
	@Override
	public void receive() throws WallE_Exception {
		while (this.connectionEtabli)
			try {
				byte[] imageBytes = this.retrieveNextImage();
				ByteArrayInputStream bais = new ByteArrayInputStream(imageBytes);

				this.frame = ImageIO.read(bais);
				this.frame = this.resize(this.frame, (int) this.ratio[0], (int) this.ratio[1]);
				this.addTimestampToFrame(this.frame);
				this.afficheur.setImage(SwingFXUtils.toFXImage(this.frame, null));
			}

			catch (Exception e) {
				this.afficheur
						.setImage(new Image("images/videoErreur.png", this.ratio[0], this.ratio[1], false, false));
				this.deconnection();
				throw new WallE_Exception(
						"Échec de la lecture du stream! \nEssayer de vous connecter manuellement ou alors veuillez redemarrer l'application et l'auto",
						WallE_ErrorLevel.ERREUR_FATALE, LocalDateTime.now());
			}
	}

	/**
	 * Permet de redimensionner le BufferedImage utilisé pour afficher les données
	 * du stream vidéo.
	 *
	 * @param img  : le BufferedImage a redimensionner.
	 * @param newW : la nouvelle largeur souhaitée
	 * @param newH : la nouvelle hauteur souhaitée
	 * @return : dimg, le nouvel BufferedImage disposant des dimensions souhaitées
	 */
	private BufferedImage resize(BufferedImage img, int newW, int newH) {
		java.awt.Image tmp = img.getScaledInstance(newW, newH, java.awt.Image.SCALE_SMOOTH);
		BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

		Graphics2D g2d = dimg.createGraphics();
		g2d.drawImage(tmp, 0, 0, null);
		g2d.dispose();

		return dimg;
	}

	/**
	 * Permet d'obtenir les données représentant l'image suivante du stream vidéo
	 *
	 * @return : imageBytes : le tableau contenant les données de l'image suivante.
	 * @throws IOException : exception lancée s'il est impossible de lire les
	 *                     données envoyées par le stream vidéo
	 */
	private byte[] retrieveNextImage() throws IOException {
		int currByte = -1;

		boolean captureContentLength = false;
		StringWriter contentLengthStringWriter = new StringWriter(128);
		StringWriter headerWriter = new StringWriter(128);

		int contentLength = 0;

		while ((currByte = this.urlStream.read()) > -1)
			if (captureContentLength) {
				if (currByte == 10 || currByte == 13) {
					contentLength = Integer.parseInt(contentLengthStringWriter.toString());
					break;
				}
				contentLengthStringWriter.write(currByte);

			} else {
				headerWriter.write(currByte);
				String tempString = headerWriter.toString();
				int indexOf = tempString.indexOf(CONTENT_LENGTH);
				if (indexOf > 0)
					captureContentLength = true;
			}

		// 255 indicates the start of the jpeg image
		while ((this.urlStream.read()) != COMMAND_FLAG) {
			// just skip extras
		}

		// rest is the buffer
		byte[] imageBytes = new byte[contentLength + 1];
		// since we ate the original 255 , shove it back in
		imageBytes[0] = (byte) COMMAND_FLAG;
		int offset = 1;
		int numRead = 0;
		while (offset < imageBytes.length
				&& (numRead = this.urlStream.read(imageBytes, offset, imageBytes.length - offset)) >= 0)
			offset += numRead;

		return imageBytes;
	}

	/**
	 * Permet de modifier la valeur de l'attribut URL qui conserve l'url du stream
	 * vidéo.
	 *
	 * @param lien : le lien du stream vidéo
	 * @throws WallE_Exception : exception levée si le lien de la vidéo est invalide
	 */
	public void setURL(String lien) throws WallE_Exception {
		try {
			this.url = new URL(lien);
		} catch (MalformedURLException e) {
			throw new WallE_Exception("lien de la video invalide!", WallE_ErrorLevel.AVERTISSEMENT,
					LocalDateTime.now());
		}
	}

	/**
	 * non utilisé
	 */
	@Override
	public void transmit(int[] data) throws WallE_Exception {

	}

	/**
	 * Vérifie l'état de la connexion avec le stream vidéo
	 *
	 * @return : connectionEtabli, true si la connexion est active
	 */
	@Override
	public boolean verifierConnection() {
		return this.connectionEtabli;
	}

}