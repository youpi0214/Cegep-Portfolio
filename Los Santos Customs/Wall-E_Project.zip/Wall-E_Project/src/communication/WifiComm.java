package communication;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.LocalDateTime;

import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 * Classe gérant la connection avec une voiture programmée, elle s'occupe de la
 * transmission et de la reception de données
 *
 * @author Los Santos Customs
 *
 */
public class WifiComm extends Service<Void> implements Connection {

	/**
	 * tranmetteur de données vers l'auto
	 */
	private static OutputStream transmitter;

	/**
	 * définit le receveur de données
	 *
	 * @param receiver objet interceptant les données envoyées par la voiture
	 */
	private static void setReceiver(InputStream receiver) {
	}

	/**
	 * définit le transmetteur de données
	 *
	 * @param transmitter objet envoyant des données vers la voiture
	 */
	private static void setTransmitter(OutputStream transmitter) {
		WifiComm.transmitter = transmitter;
	}

	/**
	 * adresse ip du server de la voiture
	 */
	private String ipAdress;
	/**
	 * numéro de port de connection
	 */
	private int portNumber;

	/**
	 * objet servant de lien avec l'auto
	 */
	private Socket client;

	/**
	 * Stockeur de données temporaire
	 */
	private ObservableList<Integer> buffer;

	private boolean receptionFinie;

	SimpleIntegerProperty alerteConnectionInterrompu;

	/**
	 * Construteur par defaut, définit l'adresse ip et le port où se connecter avec
	 * les valeur par défaut
	 */
	public WifiComm() {
		this(DEFAULT_IP, DEFAULT_PORT_NUMBER);
	}

	/**
	 * Ce contructeur définit l'adresse ip et le port où se connecter avec les
	 * valeurs données par l'utilisateur
	 *
	 * @param pIpAdress   adresse ip données par l'utilisateur
	 * @param pPortNumber port de connection donné par l'utilisateur
	 */
	public WifiComm(String pIpAdress, int pPortNumber) {
		this.setIpAdress(pIpAdress);
		this.setPortNumber(pPortNumber);
		this.alerteConnectionInterrompu = new SimpleIntegerProperty(1);
		// stockeur de données temporaire initialisé
		this.buffer = FXCollections.observableArrayList();
	}

	@Override
	protected Task<Void> createTask() {

		return new Task<Void>() {

			@Override
			protected Void call() throws Exception {
				WifiComm.this.receive();
				return null;
			}
		};
	}

	@Override
	public boolean deconnection() {

		boolean deconnection = true;
		if (this.verifierConnection()) {
			deconnection = false;
			try {
				transmitter.flush();
				this.client.shutdownInput();
				this.client.shutdownOutput();
				transmitter = null;
				this.getBuffer().clear();
				this.client.close();

				if (this.client.isClosed() && this.cancel()) {
					// TODO à marquer dans le log
					System.out.println("Déconnection avec succès");
					deconnection = true;
				} else
					throw new IOException(); // TODO le try catch va etre enlever pour try catch va etre deplacer dans
												// le controleur
			} catch (IOException e) {
				System.err.println("Erreur de déconnection");
			}
		}

		return deconnection;
	}

	public SimpleIntegerProperty getAlerteConnectionInterrompu() {
		return this.alerteConnectionInterrompu;
	}

	/**
	 * retourne le stockeur temporaire de donnees
	 *
	 * @return
	 */
	public ObservableList<Integer> getBuffer() {
		return this.buffer;
	}

	public String getIpAdress() {
		return this.ipAdress;
	}

	public int getPortNumber() {
		return this.portNumber;
	}

	@Override
	public boolean initConnection() {
		boolean f = true;
		try {
			this.client = new Socket(this.getIpAdress(), this.getPortNumber());
			setReceiver(this.client.getInputStream());
			setTransmitter(this.client.getOutputStream());
			this.restart();
			this.alerteConnectionInterrompu.set(0);
		} catch (UnknownHostException e) {
			System.err.println("Host introuvable");
			f = false;
		} catch (IOException e) {
			System.err.println("Erreur de connection");
			f = false;
		}
		return f;
	}

	public boolean isReceptionFinie() {
		return this.receptionFinie;
	}

	@Override
	public void receive() throws WallE_Exception {
		try {
			while (this.verifierConnection()) {
				int temp;

				if (!this.client.isInputShutdown() && this.client.getInputStream().read() == COMMAND_FLAG) {
					this.receptionFinie = false;
					this.buffer.add(null);

					// tant que la délimitation des données n'est pas rencontrée, on continue à
					// stocker les infos reçues
					while ((temp = this.client.getInputStream().read()) != COMMAND_FLAG)
						this.buffer.add(temp);

					this.receptionFinie = true;
					this.buffer.remove(0);
					this.buffer.clear();
				}
			}
		} catch (Exception e) {
			System.err.println("connection perdue");
			this.alerteConnectionInterrompu.set(1);
		}

	}

	private void setIpAdress(String pIpAdress) {
		this.ipAdress = pIpAdress;
	}

	private void setPortNumber(int pPortNumber) {
		this.portNumber = pPortNumber;
	}

	@Override
	public String toString() {

		return "IP Adress : " + this.ipAdress + "; " + "Port Number : " + this.portNumber;
	}

	@Override
	public void transmit(int[] data) throws WallE_Exception {
		if (transmitter != null) {
			if (this.verifierConnection())
				try {
					transmitter.write(COMMAND_FLAG);
					for (int a : data)
						transmitter.write(a);
					transmitter.write(COMMAND_FLAG);
				} catch (IOException e) {
					throw new WallE_Exception("erreur de transmission", WallE_ErrorLevel.AVERTISSEMENT,
							LocalDateTime.now());
				}
		}

		else
			throw new WallE_Exception("pas de connexion", WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now());
	}

	@Override
	public boolean verifierConnection() {

		return this.client != null && this.client.isConnected() && !this.client.isClosed()
				&& !this.client.isInputShutdown() && !this.client.isOutputShutdown();
	}

}
