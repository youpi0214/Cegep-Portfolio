package application;

import controleur.ControleurWallE;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Classe application : s'occupe de lancer l'application et de créer le
 * contôleur principal de l'app
 *
 * @author Los Santos Customs
 *
 */
public class ApplicationWallE extends Application {

	/**
	 * Lancement de l'application
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		Application.launch(args);
	}

	/**
	 * Contrôleur de l'application
	 */
	private ControleurWallE controleur;

	/**
	 * Lancement de l'application : créé le contrôleur et un Stage pour l'interface
	 * graphique
	 */
	@Override
	public void start(Stage stage) throws Exception {
		this.controleur = new ControleurWallE(stage);
		stage.setScene(this.controleur.getScene());
		stage.show();
	}

}
