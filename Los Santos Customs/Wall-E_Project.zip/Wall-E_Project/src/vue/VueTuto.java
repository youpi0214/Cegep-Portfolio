package vue;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import controleur.ControleurWallE;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * Classe de Vue qui permet d'afficher des tutoriels pour les utilisateurs moins
 * expérimentés
 *
 * @author Los Santos Customs
 *
 */
public class VueTuto extends VueParent {

	/**
	 * L'URL de l'image qu'on recherche, sans le .png
	 */
	@FXML
	public ImageView imvTuto;

	/**
	 * Le texte complet contenu dans le tutoriel
	 */
	@FXML
	public Label lblTexte;

// Attributs de fenêtre
	private Scene scene;
	private ControleurWallE controleurPrincipal;

	/**
	 * Constructeur de l'interface VueTuto, s'occupe d'appeller la classe mère,
	 * d'initialiser l'interface et d'associer le contrôleur principal
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 * @return
	 */
	public VueTuto(Stage stage, ControleurWallE ctrl, String tutoTexte, String imageTuto) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		this.controleurPrincipal.setVue(this);
		this.lblTexte.setText(tutoTexte);
		this.imvTuto.setImage(new Image("images/" + imageTuto + ".png"));

	}

	@Override
	protected void ecouteurClavier() {
	}

	/**
	 * Méthode qui s'occupe de ramener la dernière interface ouverte gardée en
	 * mémoire. S'appelle lorsqu'on appuie sur le bouton retour
	 *
	 * @param event - Le clic de la souris sur le bouton retour.
	 */
	@FXML
	private void handleRetour(Event event) {
		this.controleurPrincipal.backupLoad();
	}

	/**
	 * Initialise tout ce qui est du FXML et de la fenêtre JavaFX, S'occupe
	 * également du CSS et du visuel de l'application
	 *
	 * @param stage - La fenêtre de l'application
	 */
	private void initialize(Stage stage) {

		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/interfaceWallETuto.fxml"));

			fxmlLoader.setController(this);

			Parent root = fxmlLoader.load();

			this.scene = new Scene(root);

			this.scene.getStylesheets().setAll("/styles/cssTuto.css");

			this.stage = stage;
			stage.setResizable(false);
			stage.setTitle("Fenêtre de Tutoriels");
			stage.getIcons().set(0, new Image("images/iconAide.png"));
			stage.setScene(this.scene);

		} catch (IOException ex) {
			Logger.getLogger(VueTuto.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * Associe le contrôleur principal à l'attribut local
	 */
	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}

}
