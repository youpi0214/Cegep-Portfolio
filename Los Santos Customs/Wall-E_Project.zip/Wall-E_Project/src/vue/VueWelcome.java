package vue;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import controleur.ControleurWallE;
import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import modele.TutoEnums;

/**
 * Classe d'introduction qui s'ouvre lorsque l'utilisateur démarre
 * l'application. Il sera confronté aux deux options possibles pour contrôler le
 * robot. Il pourra également accéder aux choix de manettes ou bien d'afficher
 * les tutoriels d'utilisation
 *
 * @author Los Santos Customs
 *
 */
public class VueWelcome extends VueParent {

	/**
	 * Attribut qui s'occupe de l'animation dur les options à sélectionner à
	 * l'accueil
	 */
	private SequentialTransition sequentialTransition;

//	Attributs et composantes sur l'interface graphique
	@FXML
	private ImageView imVAuto;
	@FXML
	private ImageView imVManuel;
	@FXML
	private ImageView btnOption;
	@FXML
	private ImageView btnAide;

	// Attributs de fenêtre
	private Scene scene;
	private ControleurWallE controleurPrincipal;

	/**
	 * Constrcteur de l'interface VueAuto, s'occupe d'appeller la classe mère,
	 * d'initialiser l'interface et d'associer le contrôleur principal, envoie la
	 * vue au contrôleur pour qu'il soit au courant de quelle vue est active
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 */
	public VueWelcome(Stage stage, ControleurWallE ctrl) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		ctrl.setVue(this);
	}

	@Override
	protected void ecouteurClavier() {
		// ne fait rien
	}

	/**
	 * Retourne la scene de la fenêtre
	 *
	 * @return stage - la scene de l'application
	 */
	@Override
	public Scene getScene() {
		return this.scene;
	}

	/**
	 * Méthode qui s'occupe de faire une animation lorsque l'utilisateur passe sa
	 * souris sur une des deux options disponibles sur l'écran d'accueil. Cette
	 * animation n'a pas de fain et aide l'utilisateur à savoir si les images au
	 * milieu sont des boutons ou non
	 *
	 * @param event
	 */
	@FXML
	private void handleAnimation(Event event) {

		RotateTransition rotateTransition1 = new RotateTransition(Duration.millis(150), (ImageView) event.getSource());
		rotateTransition1.setByAngle(5f);
		rotateTransition1.setCycleCount(2);
		rotateTransition1.setAutoReverse(true);

		RotateTransition rotateTransition2 = new RotateTransition(Duration.millis(150), (ImageView) event.getSource());
		rotateTransition2.setByAngle(-5f);
		rotateTransition2.setCycleCount(2);
		rotateTransition2.setAutoReverse(true);

		this.sequentialTransition = new SequentialTransition();
		this.sequentialTransition.getChildren().addAll(rotateTransition1, rotateTransition2);
		this.sequentialTransition.setCycleCount(Animation.INDEFINITE);
		this.sequentialTransition.setAutoReverse(true);
		this.sequentialTransition.play();
	}

	/**
	 * Méthode qui s'occupe d'arrêter l'animation et de remettre les icônes à leurs
	 * places lorsque la souris quitte le bouton
	 *
	 * @param event - Le moment où la souris quitte le périmètre du bouton
	 */
	@FXML
	private void handleAnimationReset(Event event) {
		this.sequentialTransition.stop();
		((ImageView) event.getSource()).rotateProperty().set(0);
	}

	/**
	 * Ouvre un tutoriel de base qui explique comment fonctionne l'interface de
	 * bienvenue de l'application
	 *
	 * @param event - Le clic de souris sur le bouton tuto
	 */
	@FXML
	private void handleTuto(Event event) {
		this.controleurPrincipal.backupVue();
		new VueTuto(this.stage, this.controleurPrincipal, TutoEnums.TUTOMENU.getTexteTuto(),
				TutoEnums.TUTOMENU.getImageString());
	}

	/**
	 * Initialise tout ce qui est du FXML et de la fenêtre JavaFX, S'occupe
	 * également du CSS et du visuel de l'application, s'occupe aussi de créer les
	 * icônes pour le choix de mode
	 *
	 * @param stage - La fenêtre de l'application
	 */
	@FXML
	private void initialize(Stage stage) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/interfaceWallEWelcome.fxml"));
			fxmlLoader.setController(this);
			this.stage = stage;
			Parent root = fxmlLoader.load();
			this.scene = new Scene(root);
			// Chargement de la feuille de style
			this.scene.getStylesheets().setAll("/styles/cssWelcome.css");

			this.imVAuto.setImage(new Image("images/iconAuto.png"));
			this.imVAuto.getStyleClass().add("imVAuto");
			this.imVManuel.setImage(new Image("images/iconManuel.png"));
			this.imVManuel.getStyleClass().add("imVManuel");
			this.btnOption.setImage(new Image("images/iconOptions.png"));
			this.btnAide.setImage(new Image("images/iconAide.png"));
			this.loadVue();

		} catch (IOException ex) {
			Logger.getLogger(VueWelcome.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void loadVue() {

		this.stage.setResizable(false);
		this.stage.getIcons().add(new Image("images/iconManette.png"));
		this.stage.getIcons().set(0, new Image("images/iconManette.png"));
		this.stage.setTitle("Welcome to Wall-E");
		this.stage.setScene(this.scene);

	}

	/**
	 * Associe le contrôleur principal à l'attribut local
	 */
	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}

}
