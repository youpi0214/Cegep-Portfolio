package vue;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import communication.WifiComm;
import controleur.ControleurWallE;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * Interface graphique prévu pour la connection au robot, permet à l'utilisateur
 * de sélectionner une adresse ip et un port ou de sélectionner les paramêtres
 * par défaut prévus par le programmeur
 *
 * @author Los Santos Customs
 *
 */
public class VueChoixIP extends VueParent {

//	Espaces pour entrer l'adresse IP et le port pour la connexion
	@FXML
	public TextField txtFieldIP1;
	@FXML
	public TextField txtFieldIP2;
	@FXML
	public TextField txtFieldIP3;
	@FXML
	public TextField txtFieldIP4;
	@FXML
	public TextField txtFieldPort;
	ObservableList<TextField> listTextField;

	/**
	 * Check box pour sélectionner si l'on veut es paramètres par défaut ou non
	 */
	@FXML
	private CheckBox cBoxParam;

	/**
	 * Si le robot est connecté ou non
	 */
	boolean connected;

	// Attributs de fenêtre
	private Scene scene;
	private ControleurWallE controleurPrincipal;

	/**
	 * Constrcteur de l'interface VueChoixIP, s'occupe d'appeller la classe mère,
	 * d'initialiser l'interface et d'associer le contrôleur principal
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 */
	public VueChoixIP(Stage stage, ControleurWallE ctrl) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		this.controleurPrincipal.setVue(this);
	}

	@Override
	protected void ecouteurClavier() {

		this.scene.setOnKeyPressed(ke -> {
			System.out.println("Touche : " + ke.getCode().toString());

			switch (ke.getCode().toString()) {

			case "ENTER":
				this.handleConnexion(new ActionEvent());
				break;

			}
		});

	}

	/**
	 * Méthode qui permet de connecter l'application Java au robot, ouvre
	 * l'application si la connexion est réussie
	 *
	 * @param event - Le clic de la souris sur le bouton de connexion
	 */
	@FXML
	private void handleConnexion(Event event) {

		// ouvre l'interface si la connection reussi
		if (this.controleurPrincipal.connexionConfirmer(this.cBoxParam.isSelected())) {

			if (((ImageView) this.controleurPrincipal.tempEvent.getSource()).getId().equals("imVAuto")) {
				new VueAuto(this.stage, this.controleurPrincipal);
				this.controleurPrincipal.backupVue();
			} else {
				new VueManuel(this.stage, this.controleurPrincipal);
				this.controleurPrincipal.backupVue();
			}
		} else
			JOptionPane.showMessageDialog(null, "Veuillez vérifier les information rentrées", "Échec de connection",
					JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * Rétablit les paramètres par défaut si la box est cliquée, vide les champs
	 * texte et active les champs texte si l'on veut entrer une IP et un port
	 * manuellement
	 *
	 * @param event - Le clic de la souris sur la checkbox
	 */
//	TODO C'EST VRAIMENT ÇA L'IP PAR DÉFAUT??
	@FXML
	private void handleDefault(Event event) {
		if (this.cBoxParam.isSelected()) {
			this.txtFieldIP1.setDisable(true);
			this.txtFieldIP1.setText("192");
			this.txtFieldIP2.setDisable(true);
			this.txtFieldIP2.setText("168");
			this.txtFieldIP3.setDisable(true);
			this.txtFieldIP3.setText("1");
			this.txtFieldIP4.setDisable(true);
			this.txtFieldIP4.setText("1");
			this.txtFieldPort.setDisable(true);
			this.txtFieldPort.setText("" + WifiComm.DEFAULT_PORT_NUMBER);
		} else {
			this.txtFieldIP1.setDisable(false);
			this.txtFieldIP1.setText("");
			this.txtFieldIP2.setDisable(false);
			this.txtFieldIP2.setText("");
			this.txtFieldIP3.setDisable(false);
			this.txtFieldIP3.setText("");
			this.txtFieldIP4.setDisable(false);
			this.txtFieldIP4.setText("");
			this.txtFieldPort.setDisable(false);
			this.txtFieldPort.setText("");
		}
	}

	/**
	 * Initialise tout ce qui est du FXML et de la fenêtre JavaFX, S'occupe
	 * également du CSS et du visuel de l'application, vérifie également si
	 * l'utilisateur entre des données valides
	 *
	 * @param stage - La fenêtre de l'application
	 */
	private void initialize(Stage stage) {

		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/interfaceWallEChoixIP.fxml"));

			fxmlLoader.setController(this);

			Parent root = fxmlLoader.load();

			this.scene = new Scene(root);

			this.scene.getStylesheets().setAll("/styles/cssIP.css");

			this.stage = stage;
			stage.setResizable(false);
			stage.setTitle("Choisir IP");
			stage.getIcons().set(0, new Image("images/iconManuel.png"));
			stage.setScene(this.scene);
			this.ecouteurClavier();
			this.verifInfos();

		} catch (IOException ex) {
			Logger.getLogger(VueChoixIP.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * Associe le contrôleur principal à l'attribut local
	 */
	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}

	/**
	 * Véfirie si les entrées écrites sur l'interface graphique sont valides et
	 * conformes au format préscrit par le programmeur
	 */
	private void verifInfos() {

		this.listTextField = FXCollections.observableArrayList(this.txtFieldIP1, this.txtFieldIP2, this.txtFieldIP3,
				this.txtFieldIP4, this.txtFieldPort);

		for (TextField textField : this.listTextField)
			textField.textProperty().addListener((ChangeListener<String>) (observable, oldValue, newValue) -> {
				if (!newValue.matches("\\d*"))
					textField.setText(newValue.replaceAll("[^\\d]", ""));
			});
		this.connected = false;
	}

}
