package vue;

import communication.VideoRender;
import controleur.ControleurWallE;
import debug.WallE_Exception;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import modele.TutoEnums;

/**
 * Classe Parent des interfaces graphiques, contient des méthodes qui sont
 * présentes dans tous ses sous-composants. Elle s'occupe également du
 * chargement de chacune des interfaces, ce qui facilite le déplacement entre
 * les classes graphiques
 *
 * @author Los Santos Customs
 *
 */
public abstract class VueParent {

//	Liste de tous les attributs présents sur l'interface graphique
	@FXML
	private Label lblVitesse;
	@FXML
	private Label lblCinetique;
	@FXML
	private Label lblObstacle;
	@FXML
	private Label lblMessage;
	@FXML
	private ImageView btnOption;
	@FXML
	private ImageView btnAide;
	@FXML
	private CheckMenuItem afficherAcherLog;

	// elements pour l'affichage du log
	@FXML
	private TextFlow txtFL_log;
	@FXML
	protected ScrollPane logWrapper;
	@FXML
	protected AnchorPane logContainer;

//	Liste des éléments pour jouer la vidéo du robot (Live camera Feed)
	@FXML
	protected ImageView imageVideo;
	protected VideoRender render;

	// Attributs de fenêtre
	protected Scene scene;
	protected ControleurWallE controleurPrincipal;
	protected Stage stage;

	/**
	 * Le constructeur parent s'occupe simplement d'affecter le contrôleur reçu au
	 * contrôleur en attribut
	 *
	 * @param ctrl - Le contrôleur principal de l'application
	 */
	public VueParent(ControleurWallE ctrl) {
		this.controleurPrincipal = ctrl;
	}

	protected abstract void ecouteurClavier();

	/**
	 * Retourne le controleur principal de l'application
	 *
	 * @return le controleur principal de l'application
	 */
	public ControleurWallE getControleur() {
		return this.controleurPrincipal;
	}

	public Label getLblCinetique() {
		return this.lblCinetique;
	}

	public Label getLblMessage() {
		return this.lblMessage;
	}

	public Label getLblObstacle() {
		return this.lblObstacle;
	}

	public Label getLblVitesse() {
		return this.lblVitesse;
	}

	/**
	 * Retourne la scene de la fenêtre
	 *
	 * @return stage - la scene de l'application
	 */
	public Scene getScene() {
		return this.scene;

	}

	/**
	 * Retourne la fenêtre de l'application
	 *
	 * @return stage - la fenêtre de l'application
	 */
	public Stage getStage() {
		return this.stage;
	}

	public TextFlow getTxtFL_log() {
		return this.txtFL_log;
	}

	/**
	 * S'occupe de retourner au menu principal en créant un objet VueWelcome
	 *
	 * @param event - Le clic sur le bouton de retour au menu
	 */
	@FXML
	private void handleBackToMenu(Event event) {

		this.quitMode_ou_Appli();
		this.controleurPrincipal.connectionFermer();
		this.controleurPrincipal.backupDestruction();
		this.loadMenu(this.stage, this.controleurPrincipal);

	}

	@FXML
	private void handleChargerStream(Event event) {
		if (this instanceof VueManuel || this instanceof VueAuto)
			this.controleurPrincipal.chargerStream();
	}

	/**
	 * Permet de mettre dans une string, toutes les
	 *
	 * @param event
	 */
	@FXML
	private void handleCommandes(Event event) {
		this.controleurPrincipal.backupVue();
		this.loadListeManettes(this.stage, this.controleurPrincipal);
	}

	/**
	 * Permet de changer entre les deux modes de conduite
	 *
	 * @param event : le clic sur le changement de mode
	 */
	@FXML
	private void handleDriving(Event event) {

		if (event.getSource() instanceof MenuItem) {
			if (((MenuItem) event.getSource()).getText().equals("Auto Driving")
					&& !(this.controleurPrincipal.getVue() instanceof VueAuto)) {
				this.quitMode_ou_Appli();
				new VueAuto(this.stage, this.controleurPrincipal);
				this.controleurPrincipal.backupVue();

			} else if (((MenuItem) event.getSource()).getText().equals("Manual driving")
					&& !(this.controleurPrincipal.getVue() instanceof VueManuel)) {
				this.quitMode_ou_Appli();
				new VueManuel(this.stage, this.controleurPrincipal);
				this.controleurPrincipal.backupVue();
			}
		} else {
			this.controleurPrincipal.tempEvent = event;
			this.controleurPrincipal.connexionVerifier();
		}

	}

	/**
	 * S'occupe d'afficher ou d'enlever le log selon les besoins de l'utilisateur.
	 *
	 */
	protected void handleLog() {

		this.logWrapper.visibleProperty().bind(this.afficherAcherLog.selectedProperty());
		this.txtFL_log.visibleProperty().bind(this.afficherAcherLog.selectedProperty());
		this.logContainer.visibleProperty().bind(this.afficherAcherLog.selectedProperty());

		this.logContainer.prefHeightProperty().bind(this.txtFL_log.prefHeightProperty());
		this.logContainer.prefWidthProperty().bind(this.txtFL_log.prefWidthProperty());

		this.logWrapper.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
		this.logWrapper.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
	}

	/**
	 * TODO ENVOYER LE MESSAGE AU ROBOT Méthode qui s'occupe d'envoyer la demande au
	 * contrôleur d'envoyer un message texte au robot, pour l'afficher sur le module
	 * d'écran au LED
	 *
	 * @param event - Le clic sur l'option de message
	 */
	@FXML
	private void handleMessage(Event event) {
		this.lblMessage.setText(this.controleurPrincipal.message(event));
	}

	/**
	 * Appelle la méthode mouvement() du controleur pour envoyer une commande au
	 * robot
	 *
	 * @param event - Le clic de la souris sur le mouvement voulu
	 */
	@FXML
	private void handleMouvement(Event event) {
		if (this.controleurPrincipal.getVue() instanceof VueManuel)
			this.controleurPrincipal.mouvement(event);
	}

	/**
	 * Permet de quitter le programme et de fermer la connexion en cours
	 *
	 * @param event
	 */
	@FXML
	private void handleQuitter(Event event) {
		this.quitMode_ou_Appli();
		this.controleurPrincipal.connectionFermer();
		System.exit(0);
	}

	/**
	 * Réinitialise les infos afficher sur la fenêtre et remet le tout à zéro et
	 * envoie une commande à l'auto pour l'ordonner de reinitialiser ses attributs
	 * (distance parcourue, temps, ajustement camera par defaut)
	 *
	 * @param event
	 */
	@FXML
	private void handleReset(Event event) {

		if (this instanceof VueAuto || this instanceof VueManuel) {
			this.txtFL_log.getChildren().clear();
			this.controleurPrincipal.alerterAutoModeChange();
			this.controleurPrincipal.resetInterface();
			this.controleurPrincipal.stopManette();
			if (this instanceof VueAuto)
				this.controleurPrincipal.stopAI_autonome();
			this.getLblMessage().setText("");
			this.controleurPrincipal.startManette();
		}

	}

	@FXML
	private void handleStopResumeLog(Event event) {
		this.controleurPrincipal.stopResumeLog();
	}

	@FXML
	private void handleTuto(Event event) {

		this.controleurPrincipal.backupVue();

		if (event.getSource() instanceof MenuItem)
			switch (((MenuItem) event.getSource()).getText()) {
			case ("Tutoriel Contrôles"): {
				new VueTuto(this.stage, this.controleurPrincipal, TutoEnums.TUTOCOMMANDES.getTexteTuto(),
						TutoEnums.TUTOCOMMANDES.getImageString());
				break;
			}
			case ("Tutoriel Auto Driving"): {
				new VueTuto(this.stage, this.controleurPrincipal, TutoEnums.TUTOAUTO.getTexteTuto(),
						TutoEnums.TUTOAUTO.getImageString());
				break;
			}
			case ("Tutoriel Manuel"): {
				new VueTuto(this.stage, this.controleurPrincipal, TutoEnums.TUTOMANUEL.getTexteTuto(),
						TutoEnums.TUTOMANUEL.getImageString());
				break;
			}
			}

	}

	protected void loadListeManettes(Stage stage, ControleurWallE ctrl) {
		new ListeManette(stage, ctrl);
	}

	/**
	 * S'occupe de charger l'interface graphique de l'accueil de l'utilisateur
	 * (ramène au menu principal)
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 */
	protected void loadMenu(Stage stage, ControleurWallE ctrl) {
		new VueWelcome(stage, ctrl);
	}

	/**
	 * S'occupe de charger l'interface graphique du contrôle manuel du robot
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 */
	protected void loadVuePrecedente() {
		this.controleurPrincipal.backupLoad();
	}

	/**
	 * preparation pour changer de mode ou fermer l'application
	 */
	private void quitMode_ou_Appli() {
		this.controleurPrincipal.alerterAutoModeChange();
		this.controleurPrincipal.desactiverInterfaceUpdate();
		this.controleurPrincipal.stopModele();
		this.controleurPrincipal.stopManette();
		this.controleurPrincipal.stopAI_autonome();
		if (this instanceof VueManuel || this instanceof VueAuto)
			this.render.deconnection();
		System.gc();
	}

	/**
	 * Associe le contrôleur principal à la classe qui l'appelle, sera redéfinie par
	 * les enfants
	 */
	public abstract void setControleurPrincipal(ControleurWallE controleurPrincipal);

	public void startStream(String lien) throws WallE_Exception {
		this.render.setURL(lien);
		this.render.restart();
	}
}
