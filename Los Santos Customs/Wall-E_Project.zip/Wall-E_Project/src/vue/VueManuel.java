package vue;

import java.util.logging.Level;
import java.util.logging.Logger;

import communication.VideoRender;
import controleur.ControleurWallE;
import debug.WallE_Exception;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Classe qui s'occupe de l'interface de contrôle manuel du robot, c'est
 * essentiellement la même interface que celle du contrôle automatique, mais
 * avec des boutons Avant Arrière Gauche et Droite. Ces boutons peuvent peuvent
 * également être bindée à une manette ou le clavier d'ordinateur
 *
 * @author Los Santos Customs
 *
 */
public class VueManuel extends VueParent {

	@FXML
	private Label lblForceCollision;
	@FXML
	private Label lblTempsImpact;
	@FXML
	private Button btnAvant;
	@FXML
	private Button btnArriere;
	@FXML
	private Button btnGauche;
	@FXML
	private Button btnDroite;

	/**
	 * Constrcteur de l'interface VueAuto, s'occupe d'appeller la classe mère,
	 * d'initialiser l'interface et d'associer le contrôleur principal, ajout
	 * également des écouteurs aux touches du clavier pour faciliter le contrôle du
	 * robot
	 *
	 * @param stage - La fenêtre de l'application
	 * @param ctrl  - Le contrôleur principal de l'application
	 */
	public VueManuel(Stage stage, ControleurWallE ctrl) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		this.controleurPrincipal.setVue(this);

		this.ecouteurClavier();
		this.controleurPrincipal.activerInterfaceUpdate();
		this.controleurPrincipal.startModele();
	}

	/**
	 * Associe un écouteur sur quatre touches du clavier, Soit les flèches du haut,
	 * du bas, celle de gauche et celle de droite. Ces écouteurs permettent à
	 * l'utilisateur de contrôler le robot en temps réel avec son clavier
	 * d'ordinateur
	 */
	@Override
	protected void ecouteurClavier() {

		this.scene.setOnKeyPressed(ke -> {
//			System.out.println("Touche : " + ke.getCode().toString()); TODO rajouter le controle de vitesse et de camera

			switch (ke.getCode().toString()) {

			case "UP":
				this.btnAvant.fire();
				break;
			case "DOWN":
				this.btnArriere.fire();
				break;
			case "LEFT":
				this.btnGauche.fire();
				break;
			case "RIGHT":
				this.btnDroite.fire();
				break;
			}
		});

		// stop la voiture lorsqu'on lache la touche du clavier
		this.scene.setOnKeyReleased(ke -> {
			switch (ke.getCode().toString()) {

			case "UP":
			case "DOWN":
			case "LEFT":
			case "RIGHT":
				this.controleurPrincipal.mouvement(new ActionEvent());
				break;
			}
		});
	}

	public Label getLblForceCollision() {
		return this.lblForceCollision;
	}

	public Label getLblTempsImpact() {
		return this.lblTempsImpact;
	}

	/**
	 * Méthode appellée quand l'utilisateur fait une collision, il pourra ainsi
	 * savoir la force de la collision qui vient de se produire.
	 *
	 * @param event
	 */
	@FXML
	private void handleCollision(Event event) {
		this.controleurPrincipal.collision(true);
	}

	/**
	 * Initialise tout ce qui est du FXML et de la fenêtre JavaFX, S'occupe
	 * également du CSS et du visuel de l'application, s'occupe aussi de créer les
	 * attributs pour le flux en direct du robot
	 *
	 * @param stage - La fenêtre de l'application
	 */
	private void initialize(Stage stage) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/interfaceWallEManuelle.fxml"));
			fxmlLoader.setController(this);
			Parent root = fxmlLoader.load();
			this.scene = new Scene(root);
			this.scene.getStylesheets().setAll("/styles/cssManuel.css");
			this.stage = stage;
			this.loadVue();
			this.handleLog();
			this.render = new VideoRender(this.imageVideo);
			this.controleurPrincipal.setLogger(this.getTxtFL_log());
			this.startStream(VideoRender.VIDEO_URL);

		} catch (WallE_Exception ex) {
			this.controleurPrincipal.getLogView().logErreur(ex);
		} catch (Exception ex) {
			Logger.getLogger(VueManuel.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void loadVue() {

		this.stage.setResizable(false);
		this.stage.getIcons().set(0, new Image("images/iconManuel.png"));
		this.stage.setTitle("Wall-E Manual Driving Mode");
		this.stage.setScene(this.scene);
		this.controleurPrincipal.setLogger(this.getTxtFL_log());
	}

	/**
	 * Associe le contrôleur principal à l'attribut local
	 */
	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}
}