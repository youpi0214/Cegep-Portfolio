package vue;

import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

import communication.VideoRender;
import controleur.ControleurWallE;
import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Classe Vue Auto, s'occupe de l'interface graphique qui s'affiche lorsque l'utilisateur souhaite un controle
 * automatique de la voiture.
 *
 * @author
 *
 */
/**
 * @author Claude
 *
 */
/**
 * @author Claude
 *
 */
public class VueAuto extends VueParent {

	@FXML
	private Label lblPositionX;
	@FXML
	private Label lblPositionY;
	@FXML
	private TextField txtFDistanceX;
	@FXML
	private TextField txtFDistanceY;
	@FXML
	private Button btnGo;

	/**
	 * Controleur de la classe Vue Auto, permet la création et l'initialisation du
	 * stage et ajoute les écouteurs aux touches du clavier
	 *
	 * @param stage : le stage dans lequel est stocké l'interface graphique
	 * @param ctrl  : le controleur du fxml
	 */
	public VueAuto(Stage stage, ControleurWallE ctrl) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		this.controleurPrincipal.setVue(this);

		this.ecouteurClavier();
		this.controleurPrincipal.activerInterfaceUpdate();
	}

	/**
	 * Ajoute un écouteur sur la touche qui a été pressée
	 */
	@Override
	protected void ecouteurClavier() {
		this.scene.setOnKeyPressed(ke -> {

			switch (ke.getCode().toString()) {

			case "ENTER":
				this.handleMouvement(new ActionEvent());
				break;

			}
		});

	}

	public Label getLblPositionX() {
		return this.lblPositionX;
	}

	public Label getLblPositionY() {
		return this.lblPositionY;
	}

	/**
	 * Activite l'AI de la voiture et essaie de se rendre à l'objectif désigné par
	 * l'utilisateur si celui-ci est valide
	 *
	 * @param event - Le clic de la souris sur le mouvement voulu
	 */
	@FXML
	private void handleMouvement(Event event) {
		String x = null, y = null;
		try {
			if ((x = this.txtFDistanceX.getText()) != null && !x.isEmpty() && !x.equals("-") && !x.equals("+")
					&& (y = this.txtFDistanceY.getText()) != null && !y.isEmpty() && !y.equals("-") && !y.equals("+")) {
				this.controleurPrincipal.setAI_Destination(Integer.parseInt(x), Integer.parseInt(y));
				this.controleurPrincipal.getLogView().logDonnees("Coordonnees valides!");
				this.controleurPrincipal.stopAI_autonome();
				this.controleurPrincipal.startAI_autonome();
				this.txtFDistanceX.clear();
				this.txtFDistanceY.clear();
			} else
				this.controleurPrincipal.getLogView()
						.logErreur(new WallE_Exception("Les informations rentrées sont insuffisants",
								WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now()));
		} catch (NumberFormatException e) {
			this.controleurPrincipal.getLogView()
					.logErreur(new WallE_Exception("Désolé, les coordonnées rentrées sont invalides",
							WallE_ErrorLevel.ERREUR_FATALE, LocalDateTime.now()));
		}
	}

	/**
	 * Permet d'initialiser le stage, charge un fxml et remplit le stage avec.
	 *
	 * @param stage : le stage dans lequel l'interface sera affichée
	 */
	private void initialize(Stage stage) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/interfaceWallEAuto.fxml"));
			fxmlLoader.setController(this);
			Parent root = fxmlLoader.load();
			this.scene = new Scene(root);
			this.scene.getStylesheets().setAll("/styles/cssAuto.css");
			this.stage = stage;
			this.loadVue();
			this.verifInfos();
			this.handleLog();
			this.render = new VideoRender(this.imageVideo);
			this.startStream(VideoRender.VIDEO_URL);

		} catch (WallE_Exception ex) {
			this.controleurPrincipal.getLogView().logErreur(ex);
		} catch (Exception ex) {
			Logger.getLogger(VueParent.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void loadVue() {
		this.stage.setResizable(false);
		this.stage.getIcons().set(0, new Image("images/iconAuto.png"));
		this.stage.setTitle("Wall-E Auto Driving Mode");
		this.stage.setScene(this.scene);
		this.controleurPrincipal.setLogger(this.getTxtFL_log());
	}

	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}

	/**
	 * Véfirie si les entrées écrites sur l'interface graphique sont valides et
	 * conformes au format préscrit par le programmeur
	 */
	private void verifInfos() {

		this.txtFDistanceX.textProperty().addListener((ChangeListener<String>) (observable, oldValue, newValue) -> {
			if (!newValue.matches("-?\\d+$"))
				this.txtFDistanceX.setText(newValue.replaceAll("[^-?\\d+$]", ""));
		});
		this.txtFDistanceY.textProperty().addListener((ChangeListener<String>) (observable, oldValue, newValue) -> {
			if (!newValue.matches("-?\\d+$"))
				this.txtFDistanceY.setText(newValue.replaceAll("[^-?\\d+$]", ""));
		});
	}
}
