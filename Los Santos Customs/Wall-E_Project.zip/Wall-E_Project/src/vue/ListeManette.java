package vue;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

import controleur.ControleurWallE;
import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Classe ListeManette ; Permet d'afficher l'interface qui liste les manettes
 * supportées par l'application et les manettes non supportées par
 * l'application. Cette interface permet aussi à l'utilisateur de sélectionner
 * la manette de son choix ou son clavier pour le contrôle du robot.
 *
 * @author Los Santos Customs
 *
 */
public class ListeManette extends VueParent {

	/**
	 * ListView contenant toutes les périphériques détectés sur l'ordinateur
	 */
	@FXML

	private ListView<String> lViewNSupporte;

	/**
	 * ListView contenant toutes les manttes et périphériques déjà supportés pour le
	 * contrôle du robot
	 */
	@FXML
	private ListView<String> lViewSupporte;

	// Attributs de fenêtre
	private Scene scene;
	private ControleurWallE controleurPrincipal;

	/**
	 * Constructeur de ListeManette, S'occupe d'initialiser la fenêtre, d'appeller
	 * le constructeur Parent, de stocker en mémoire le dernier mode utilisé, et de
	 * créer les deux listes de manettes à afficher à l'utilisateur
	 *
	 * @param stage       - La fenêtre de l'applciation
	 * @param ctrl        - Le contrôleur principal de l'application
	 * @param dernierMode - La derniêre interface ouverte par l'utilisateur
	 */
	public ListeManette(Stage stage, ControleurWallE ctrl) {
		super(ctrl);
		this.initialize(stage);
		this.setControleurPrincipal(ctrl);
		this.controleurPrincipal.setVue(this);

		this.fillListViews();

	}

	@Override
	protected void ecouteurClavier() {
		// ne fais rien
	}

	public void fillListViews() {
		this.controleurPrincipal.runDevicesDetection();
		ObservableList<String> manettesSupportees = FXCollections
				.observableList(this.controleurPrincipal.getListeManettesSupporte());
		this.lViewSupporte.setItems(manettesSupportees);

		ObservableList<String> manettesNSupportees = FXCollections
				.observableList(this.controleurPrincipal.getListeManettesNonSupporte());
		this.lViewNSupporte.setItems(manettesNSupportees);
	}

	/**
	 * S'occupe de délectionner un contrôleur parmi la liste de contrôleur
	 * préconfigurés. Affiche également un message d'erreur si le contrôleur
	 * séléctionné n'est pas connecté à l'ordinateur
	 *
	 * @param event - L'endroit où l'utilisateur a cliqué dan la liste
	 * @throws WallE_Exception
	 */
	@FXML
	private void handleChangerControle(Event event) {
		try {

			String controle = "";
			controle = ((ListView<String>) event.getSource()).getSelectionModel().getSelectedItem();
			System.out.println("Controle : " + controle);
			this.controleurPrincipal.controle(controle);
			this.controleurPrincipal.backupLoad();
		} catch (Exception e) {
			this.controleurPrincipal.backupLoad();
			this.controleurPrincipal.getLogView().logErreur(new WallE_Exception("Aucune manette de "
					+ ((ListView<String>) event.getSource()).getSelectionModel().getSelectedItem() + " détectée",
					WallE_ErrorLevel.AVERTISSEMENT, LocalDateTime.now()));

		}
	}

	/**
	 * S'occupe de configurer une nouvelle manette au système,envoie la demande au
	 * contrôleur principal.
	 *
	 * @param event
	 */
	@FXML
	private void handleConfigurer(Event event) {
		System.out.println("Configuration de " + this.lViewNSupporte.getSelectionModel().getSelectedItem());
		this.controleurPrincipal.manetteConfig(this.lViewNSupporte.getSelectionModel().getSelectedItem());
	}

	/**
	 * S'occupe de ramener l'utilisateur sur la dernière interface utilisée en
	 * utilisant le dernier mode stocké en mémoire
	 *
	 * @param event - Le clic de souris de l'utilisateur sur retour (non utilisé)
	 */
	@FXML
	private void handleDriving(Event event) {
		this.controleurPrincipal.backupLoad();
	}

	/**
	 * S'occupe de fermer l'application et de couper la connection avec le robot
	 *
	 * @param event
	 */
	@FXML
	private void handleQuitter(Event event) {
		this.controleurPrincipal.connectionFermer();
		System.exit(0);
	}

	/**
	 * Initialise tout ce qui est du FXML et de la fenêtre JavaFX, S'occupe
	 * également du CSS et du visuel de l'application
	 *
	 * @param stage - La fenêtre de l'application
	 */
	@FXML
	private void initialize(Stage stage) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getResource("/vue/listeManettes.fxml"));

			fxmlLoader.setController(this);
			Parent root = fxmlLoader.load();
			this.scene = new Scene(root);
			stage.setResizable(false);
			this.scene.getStylesheets().setAll("/styles/cssManuel.css");
			this.stage = stage;
			stage.getIcons().add(new Image("images/iconManette.png"));
			stage.getIcons().set(0, new Image("images/iconManette.png"));
			stage.setTitle("Choix de la manette");
			stage.setScene(this.scene);

		} catch (IOException ex) {
			Logger.getLogger(VueManuel.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * Associe le contrôleur reçu à cette classe-ci
	 */

	@Override
	public void setControleurPrincipal(ControleurWallE controleurPrincipal) {
		this.controleurPrincipal = controleurPrincipal;
	}
}