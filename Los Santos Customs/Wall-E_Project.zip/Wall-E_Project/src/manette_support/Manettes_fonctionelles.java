package manette_support;

/**
 * Enumération des différentes manettes supportées par l'application
 *
 * @author Los Santos Customs
 *
 */
enum Manettes_fonctionelles {
	Clavier("Clavier"), PS4("Wireless Controller"), SNES("8Bitdo SN30 GamePad");

	private String name;

	private Manettes_fonctionelles(String pName) {
		this.name = pName;
	}

	@Override
	public String toString() {
		return this.name;
	}

}
