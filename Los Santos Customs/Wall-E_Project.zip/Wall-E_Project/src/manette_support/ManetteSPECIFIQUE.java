package manette_support;

import java.awt.geom.Point2D;

import org.lwjgl.input.Controller;

import javafx.beans.property.SimpleObjectProperty;

/**
 * Constructeur de la classe ManetteSPECIFIQUE, classe parent de l'ensemble des
 * différentes classes manettes.
 *
 * @author Los Santos Customs
 *
 */
public abstract class ManetteSPECIFIQUE {

	private final int WRAPPER_SIZE = 2;
	private Controller device;
	private Point2D valeursAxesDeplacement;
	private Point2D valeursAxesCamera;
	Object[] data_Wrapper;
	int manettePosition;

	/**
	 * utilisé pour faire parvenir les commandes de la manettes au reste du
	 * programme
	 */
	SimpleObjectProperty<Object[]> data_link;

	/**
	 * Constructeur de la classe ManetteSPECIFIQUE, définie la manette recue en
	 * parametre en comme principale et instancie les axes de deplacement ainsi que
	 * le data link.
	 *
	 * @param pDevice : la manette en question
	 */
	public ManetteSPECIFIQUE(Controller pDevice) {
		this.device = pDevice;
		this.valeursAxesDeplacement = new Point2D.Double();
		this.valeursAxesCamera = new Point2D.Double();
		this.data_link = new SimpleObjectProperty<>();
	}

	/**
	 * Permet de remplir le data link
	 *
	 * @param deplacement : l'objet representant les axes de deplacement voulus
	 * @param camera      : l'objet representant les axes de camera voulus
	 */
	protected void fill_Data_Wrapper(Object deplacement, Object camera) {
		this.data_Wrapper = new Object[this.WRAPPER_SIZE];
		this.data_Wrapper[0] = deplacement;
		this.data_Wrapper[1] = camera;
	}

	/**
	 * Accesseur du data link
	 *
	 * @return : data_link : un objet de transport de données
	 */
	public SimpleObjectProperty<Object[]> getData_link() {
		return this.data_link;
	}

	/**
	 * Accesseur du tableau data wrapper
	 *
	 * @return : data_Wrapper : tableau de données
	 */
	protected Object[] getData_Wrapper() {
		return this.data_Wrapper;
	}

	/**
	 * Retourne la manette principale
	 *
	 * @return : la manette en question
	 */
	public Controller getDevice() {
		return this.device;
	}

	/**
	 * Accesseur de l'attribut position
	 *
	 * @return : la position de la manette
	 */
	public int getManettePosition() {
		return this.manettePosition;
	}

	/**
	 * Accesseur de l'axe de camera
	 *
	 * @return : valeursAxesCamera, l'axe de la camera
	 */
	public Point2D getValeursAxesCamera() {
		return this.valeursAxesCamera;
	}

	/**
	 * Accesseur de l'axe de deplacement
	 *
	 * @return : valeursAxesDeplacement, l'axe de deplacement
	 */
	public Point2D getValeursAxesDeplacement() {
		return this.valeursAxesDeplacement;
	}

	/**
	 * Permet de définir la position de la manette
	 *
	 * @param pos : la position de la manette
	 */
	public void setManettePosition(int pos) {
		this.manettePosition = pos;
	}

	/**
	 * Permet de modifier l'axe de la caméra
	 *
	 * @param valeursAxesCamera, le nouvel axe de camera
	 */
	public void setValeursAxesCamera(Point2D valeursAxesCamera) {
		this.valeursAxesCamera = valeursAxesCamera;
	}

	/**
	 * Permet de modifier l'axe de deplacement
	 *
	 * @param valeursAxesDeplacement, le nouvel axe de deplacement
	 */
	public void setValeursAxesDeplacement(Point2D valeursAxesDeplacement) {
		this.valeursAxesDeplacement = valeursAxesDeplacement;
	}

	protected abstract void startLoop() throws Exception;

}