package manette_support;

import org.lwjgl.input.Controller;

/**
 * Classe MappageManetteAutre, permet l'attribution de controles aux manettes
 * initialement non supportées par l'application
 *
 * @author Los Santos Customs
 *
 */
public class MappageManetteAUTRE {
	public final static String[] MESSAGES = { "avancer", "reculer", "tourner à droite", "tourner à gauche" };
	private Controller device;
	private final int TOUCHE_DEFAUT = -1;
	private final int NB_TOUCHES = 4;
	private int[] touchesSelectionnees;

	/**
	 * Constructeur de la classe MappageManetteAutre, permet le début de
	 * l'attribution des touches
	 *
	 * @param pDevice : le périphérique dont on attribue les controles
	 */
	public MappageManetteAUTRE(Controller pDevice) {
		this.device = pDevice;
		int touche = this.TOUCHE_DEFAUT;
		this.touchesSelectionnees = new int[this.NB_TOUCHES];

		for (int i = 0; i < this.NB_TOUCHES; i++) {
			System.out.println("Veuillez saisir la touche pour " + MESSAGES[i]);

			do
				touche = this.pollInput();
			while (touche == this.TOUCHE_DEFAUT);
			try {
				this.touchesSelectionnees[i] = touche;
				Thread.sleep(1500);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		new ManetteAUTRE(this.device, this.touchesSelectionnees);
	}

	/**
	 * Permet de détecter si une touche est pressée
	 *
	 * @return : i sur la touche est pressée
	 */
	public int pollInput() {
		this.device.poll();

		// POUR LES BOUTONS
		for (int i = 0; i < this.device.getButtonCount(); i++)

			if (this.device.isButtonPressed(i))
				return i;

		return this.TOUCHE_DEFAUT;
	}
}