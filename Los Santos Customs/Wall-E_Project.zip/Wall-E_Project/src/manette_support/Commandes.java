package manette_support;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import debug.WallE_ErrorLevel;
import debug.WallE_Exception;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 * Classe Commandes, régit la détection des manettes et des périphériques
 * connectés sur le systeme ainsi que l'affichage des listes des périphériques
 * détectés et utilisables a l'utilisateur.
 *
 * @author Los Santos Customs
 *
 */
public class Commandes extends Service<Void> {

	private String selection;
	ListeManettes listeManette;
	Manette manette;
	boolean manetteConnectee;

	/**
	 * Constructeur de la classe Commandes, permet de créer un nouvel objet
	 * listeManettes et de le remplir avec les périphériques fonctionnels sur le
	 * systeme
	 *
	 */
	public Commandes() {
		this.listeManette = new ListeManettes();
		this.manetteConnectee = false;
	}

	/**
	 * Permet de créer un objet manette représentant la manette physique connectée
	 * au systeme et de la définir comme connectée.
	 *
	 * @throws WallE_Exception : exception lancée si aucune manette n'est trouvée.
	 */
	public void connecterManette() throws WallE_Exception {
		try {

			this.manette = new Manette(this.listeManette, this.selection);
			this.manetteConnectee = true;

		} catch (Exception e) {
			this.manetteConnectee = false;
			this.cancel();
			throw new WallE_Exception("Erreur! manette introuvable", WallE_ErrorLevel.ERREUR_FATALE,
					LocalDateTime.now());
		}
	}

	/**
	 * Création d'un task permettant l'analyse des inputs de la manette
	 */
	@Override
	protected Task<Void> createTask() {
		return new Task<Void>() {
			@Override
			protected Void call() throws Exception {
				Commandes.this.runApp();
				return null;
			}
		};
	}

	/**
	 * Méthode permettant la détection des différentes manettes.
	 */
	public void detectConnectedComponents() {
		ListeManettes.detectManette();
	}

	/**
	 * Permet de détruire l'objet manette précédemment construit
	 */
	public void detruireManette() {
		this.manette.detruireManette();
		this.manetteConnectee = false;
	}

	/**
	 * Accesseur de la liste contenant toutes les manettes supportées par
	 * l'application
	 *
	 * @return : la liste des manettes supportées par l'application
	 */
	public HashMap<String, String> getListManette() {
		return this.listeManette.getListManetteSupportees();
	}

	/**
	 * Accesseur de la liste contenant toutes les manettes non-supportées par
	 * l'application
	 *
	 * @return : la liste des manettes non-supportées par l'application
	 */
	public List<String> getListNonsupportees() {
		return this.listeManette.listeManettesNonSupportees();
	}

	/**
	 * Accesseur de la manette, provenant de la classe Manette.
	 *
	 * @return : la manette de la classe Manette
	 */
	public ManetteSPECIFIQUE getManette() {
		return this.manette.getManette();
	}

	/**
	 * Permet de vérifier si la manette est connectée ou non.
	 *
	 * @return manetteConnectee, true si la manette est connectée.
	 */
	public boolean isManetteConnectee() {
		return this.manetteConnectee;
	}

	/**
	 * Permet de débuter l'analyse des différents inputs de la manette.
	 *
	 * @throws WallE_Exception : exception lancée si un des inputs ne peut etre lu.
	 */
	private void runApp() throws WallE_Exception {
		try {
			this.getManette().startLoop();
		} catch (Exception e) {
			throw new WallE_Exception("Erreur de lecture des inputs de la manette", WallE_ErrorLevel.ERREUR_FATALE,
					LocalDateTime.now());
		}
	}

	/**
	 * Permet de modifier l'attribut sélection par la chaine désirée
	 *
	 * @param pSelection : la nouvelle chaine
	 */
	public void setSelection(String pSelection) {
		this.selection = pSelection;
	}

}