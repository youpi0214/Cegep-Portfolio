package manette_support;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Controller;
import org.lwjgl.input.Controllers;

/**
 * Classe ListeManettes, s'occupe de la détection de périphériques ainsi que la
 * création de listes contenant les périphériques.
 *
 * @author Los Santos Customs
 *
 */
public class ListeManettes {

	public static final String[] options = { "Clavier", "PS4", "SNES" };
	public static List<Controller> devices;

	/**
	 * Permet de détecter les différentes manettes.
	 */
	public static void detectManette() {

		try {
			if (Controllers.isCreated())
				Controllers.destroy();

			Controllers.create();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}

		Controllers.poll();

		for (int i = 0; i < Controllers.getControllerCount(); i++) {
			Controller temp = Controllers.getController(i);
			if (!devices.contains(temp))
				devices.add(temp);
			System.out.println(i + ": " + Controllers.getController(i).getName());
		}
	}

	private HashMap<String, String> manettes_liste;

	/**
	 * Constructeur de la classe ListeManettes, permet d'instancier les listes et de
	 * remplir le HashMap.
	 */
	public ListeManettes() {
		devices = new ArrayList<>();
		this.manettes_liste = new HashMap<>();
		this.fillListe();

	}

	/**
	 * Méthode permettant de remplir le HashMap avec les différentes options.
	 */
	private void fillListe() {
		this.manettes_liste.put(options[0], Manettes_fonctionelles.Clavier.toString());
		this.manettes_liste.put(options[1], Manettes_fonctionelles.PS4.toString());
		this.manettes_liste.put(options[2], Manettes_fonctionelles.SNES.toString());
	}

	/**
	 * Accesseur de la liste de manettes.
	 *
	 * @return : devices, la liste de manettes.
	 */
	public List<Controller> getDevices() {
		return devices;
	}

	/**
	 * Accesseur du HashMap
	 *
	 * @return : manettes_liste, le HashMap contenant les différentes options.
	 */
	protected HashMap<String, String> getListManetteSupportees() {
		return this.manettes_liste;
	}

	/**
	 * Retourne l'index dans la liste de la manette souhaitée
	 *
	 * @param controllerName : la manette souahaitée
	 * @return : i, l'index de la manette souhaitée
	 */
	public int getPositionListe(String controllerName) {
		for (int i = 0; i < devices.size(); i++)
			if (devices.get(i).getName().equals(controllerName))
				return i;
		return -1;
	}

	/**
	 * Permet de créer la liste de tous les périphériques détectés mais non
	 * supportés par l'application.
	 *
	 * @return : pDevices, la liste des périphériques non supportés.
	 */
	public List<String> listeManettesNonSupportees() {
		List<String> pDevices = new ArrayList<>();

		for (Controller element : this.getDevices()) {
			if (!this.getListManetteSupportees().containsValue(element.getName()))
				pDevices.add(element.getName());
		}
		return pDevices;

	}

}
