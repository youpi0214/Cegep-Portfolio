package manette_support;

import java.awt.geom.Point2D;

import org.lwjgl.input.Controller;

/**
 * Classe ManetteSN30
 *
 * @author Los Santos Customs
 *
 */
public class ManetteSN30 extends ManetteSPECIFIQUE {

	/**
	 * Constructeur de la classe ManetteSN30, crée un objet de la manette SN30
	 *
	 * @param pManetteSN30 : la manette en question
	 */
	public ManetteSN30(Controller pManetteSN30) {

		super(pManetteSN30);

	}

	/**
	 * Ajuste les valeurs des axes de déplacement et attribue aux touches pressées
	 * le controle des axes de deplacement de la caméra
	 */
	@Override
	protected void startLoop() {
		boolean instance = false;
		do {
			this.getDevice().poll();
			for (int i = 0; i < this.getDevice().getAxisCount() - 1 && !instance; i++)
				instance = this.getDevice().getAxisValue(i) != this.getDevice().getAxisValue(i + 1);
		} while (!instance);
		do {
			this.getDevice().poll();

			this.setValeursAxesDeplacement(new Point2D.Double(this.getDevice().getAxisValue(3),
					Math.negateExact((int) this.getDevice().getAxisValue(2))));

			this.setValeursAxesCamera(new Point2D.Double(
					this.getDevice().isButtonPressed(0) ? 1 : 0 + (this.getDevice().isButtonPressed(4) ? -1 : 0),
					this.getDevice().isButtonPressed(3) ? 1 : 0 + (this.getDevice().isButtonPressed(1) ? -1 : 0)));

		} while (true);

	}

}
