package manette_support;

import org.lwjgl.input.Controller;

/**
 * Classe Manette, permet la détection du type de manette ainsi que la création
 * virtuelle du type de manette en question.
 *
 * @author Los Santos Customs
 *
 */
public class Manette {

	private Controller device;
	ManetteSPECIFIQUE manette;

	/**
	 * Crée un objet manette selon le nom de la manette passée en parametre
	 *
	 * @param pListeManettes : la liste contenant les manettes disponibles
	 * @param pDevice        : la manette en question
	 */
	public Manette(ListeManettes pListeManettes, String pDevice) {

		switch (pDevice) {
		case "Wireless Controller": {
			int pos = pListeManettes.getPositionListe(pDevice);
			this.manette = new ManettePS4(pListeManettes.getDevices().get(pos));
			this.manette.setManettePosition(pos);
			this.device = this.manette.getDevice();
			break;
		}
		case "8Bitdo SN30 GamePad": {
			int pos = pListeManettes.getPositionListe(pDevice);
			this.manette = new ManetteSN30(pListeManettes.getDevices().get(pos));
			this.manette.setManettePosition(pos);
			this.device = this.manette.getDevice();
			break;
		}
		default:// TODO a revoir
			this.device = (Controller) new MappageManetteAUTRE(
					pListeManettes.getDevices().get(pListeManettes.getPositionListe(pDevice)));

		}

	}

	/**
	 * Détruit l'objet manette créé plus tot
	 */
	public void detruireManette() {
		this.device = null;
		this.manette = null;
	}

	/**
	 * Accesseur du périphérique
	 *
	 * @return device : le périphérique
	 */
	public Controller getDevice() {
		return this.device;
	}

	/**
	 * Accesseur de la manette
	 *
	 * @return manette : la manette
	 */
	public ManetteSPECIFIQUE getManette() {
		return this.manette;
	}
}
