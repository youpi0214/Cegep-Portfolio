package manette_support;

import java.awt.geom.Point2D;

import org.lwjgl.input.Controller;

import modele.WallE_Utilitaire;

/**
 * Classe ManettePS4
 *
 * @author Los Santos Customs
 *
 */
public class ManettePS4 extends ManetteSPECIFIQUE {

	public final int L_xAXIS = 3;
	public final int L_yAXIS = 2;
	public final int R_xAXIS = 1;
	public final int R_yAXIS = 0;

	/**
	 * Constructeur de la classe ManettePS4, crée la manette et ajuste les zones
	 * mortes des joysticks.
	 *
	 * @param pManettePS4
	 */
	public ManettePS4(Controller pManettePS4) {
		super(pManettePS4);
		this.getDevice().setDeadZone(this.L_xAXIS, 0.2f);
		this.getDevice().setDeadZone(this.L_yAXIS, 0.2f);
		this.getDevice().setDeadZone(this.R_xAXIS, 0.2f);
		this.getDevice().setDeadZone(this.R_yAXIS, 0.2f);
		System.out.println("controller connected");
	}

	/**
	 * Méthode analysant les inputs de la manette ps4 et agit en conséquence.
	 */
	@Override
	protected void startLoop() throws Exception {

		do {
			this.getDevice().poll();
			Point2D pDeplacement = new Point2D.Double(this.getDevice().getAxisValue(this.L_xAXIS),
					-1 * this.getDevice().getAxisValue(this.L_yAXIS));

			double temp;
			Point2D pCamera = new Point2D.Double(
					WallE_Utilitaire.ajusterAxisXManetteToAngle(this.getDevice().getAxisValue(this.R_xAXIS)),
					WallE_Utilitaire.ajusterAxisYManetteToAngle(
							(temp = this.getDevice().getAxisValue(this.R_yAXIS)) < 0 ? 0 : temp));

			// envoie les commandes de manette si une de ses touches analogues a bougé
			if (!this.getValeursAxesDeplacement().equals(pDeplacement)
					|| !this.getValeursAxesCamera().equals(pCamera)) {
				this.setValeursAxesDeplacement(pDeplacement);
				this.setValeursAxesCamera(pCamera);
				this.fill_Data_Wrapper(this.getValeursAxesDeplacement(), this.getValeursAxesCamera());
				this.getData_link().set(this.getData_Wrapper());
			}

		} while (true);
	}
}
