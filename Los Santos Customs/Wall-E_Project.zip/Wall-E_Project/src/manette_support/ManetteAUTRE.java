package manette_support;

import java.awt.geom.Point2D;

import org.lwjgl.input.Controller;

/**
 * Classe ManetteAUTRE, permet la détection d'une manette initialement non
 * supportée par l'application
 *
 * @author Los Santos Customs
 *
 */
public class ManetteAUTRE extends ManetteSPECIFIQUE {

	private Point2D valeursAxesDeplacement;

	/**
	 * Constructeur de la classe ManetteAUTRE
	 *
	 * @param pDevice
	 * @param pTouchesSelectionnees
	 */
	public ManetteAUTRE(Controller pDevice, int[] pTouchesSelectionnees) {
		super(pDevice);

		do {
			this.getDevice().poll();

			this.valeursAxesDeplacement = new Point2D.Double(
					this.getDevice().isButtonPressed(pTouchesSelectionnees[2]) ? 1
							: 0 + (this.getDevice().isButtonPressed(pTouchesSelectionnees[3]) ? -1 : 0),
					this.getDevice().isButtonPressed(pTouchesSelectionnees[0]) ? 1
							: 0 + (this.getDevice().isButtonPressed(pTouchesSelectionnees[1]) ? -1 : 0));

		}

		while (true);

	}

	@Override
	protected void startLoop() {
		// TODO Auto-generated method stub

	}
}
