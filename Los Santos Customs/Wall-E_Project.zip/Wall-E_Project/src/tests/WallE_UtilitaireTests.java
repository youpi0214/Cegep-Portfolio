package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import modele.WallE_Utilitaire;

public class WallE_UtilitaireTests {

	@Before
	public void init() {

	}

	@Test
	public void testRemplirTab() {

		int[] tabInt = { 1, 6, 6, 7, 8, 9 };
		int[] tabInt1 = { 17, 64, 61, 71, 87, 91 };

		int[] tabVide = new int[6];
		int[] tabVide1 = new int[6];

		List<Integer> listTest = new ArrayList<Integer>();
		listTest.add(tabInt[0]);
		listTest.add(tabInt[1]);
		listTest.add(tabInt[2]);
		listTest.add(tabInt[3]);
		listTest.add(tabInt[4]);
		listTest.add(tabInt[5]);

		List<Integer> listTest1 = new ArrayList<Integer>();
		listTest1.add(tabInt1[0]);
		listTest1.add(tabInt1[1]);
		listTest1.add(tabInt1[2]);
		listTest1.add(tabInt1[3]);
		listTest1.add(tabInt1[4]);
		listTest1.add(tabInt1[5]);

		WallE_Utilitaire.remplirTab(tabVide, listTest);
		WallE_Utilitaire.remplirTab(tabVide1, listTest1);

		assertTrue(Arrays.equals(tabInt, tabVide));
		assertTrue(Arrays.equals(tabInt1, tabVide1));

	}

	@Test
	public void testMinIndex() {

		int[] tab1 = { 2, 7, 8, 9, 11, 15 };
		int[] tab2 = { 3, 2, 8, 100, 1, 0 };
		int[] tab3 = { 5, 15, 0, 15, 12, 1 };
		int[] tab4 = { -1, 10, 6, 10005454, 700, -24424, 0 };
		int[] tab5 = { 0, 0, 0, 0, 0, 0, 0 };
		int[] tab6 = { 70, 1000000, -100000, 0 };

		int res1 = WallE_Utilitaire.minIndex(tab1);
		int res2 = WallE_Utilitaire.minIndex(tab2);
		int res3 = WallE_Utilitaire.minIndex(tab3);
		int res4 = WallE_Utilitaire.minIndex(tab4);
		int res5 = WallE_Utilitaire.minIndex(tab5);
		int res6 = WallE_Utilitaire.minIndex(tab6);

		assertTrue(res1 == 0);
		assertTrue(res2 == 5);
		assertTrue(res3 == 2);
		assertTrue(res4 == 5);
		assertTrue(res5 == 6);
		assertTrue(res6 == 2);

	}

	@Test
	public void testAjusterAxisManette() {

		double axis = 1.0;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 0);
		axis = 0.0;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 90);
		axis = 0.5;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 45);
		axis = 0.15;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 77);
		axis = -0.0;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 90);
		axis = -1.0;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 180);
		axis = -0.75;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 158);
		axis = -0.98;
		assertTrue(WallE_Utilitaire.ajusterAxisXManetteToAngle(axis) == 178);

	}

	@Test
	public void testMultiplierCent() {

		int val = 10;
		assertTrue(WallE_Utilitaire.multiplierCent(val) == 1000);
		val = 990;
		assertTrue(WallE_Utilitaire.multiplierCent(val) == 99000);
		val = -1;
		assertTrue(WallE_Utilitaire.multiplierCent(val) == -100);
		val = 0;
		assertTrue(WallE_Utilitaire.multiplierCent(val) == 0);
		double val1 = 99.65;
		assertTrue(WallE_Utilitaire.multiplierCent(val1) == 9965);

	}

	@Test
	public void testDiviserCent() {
		double val = 150.0;
		assertTrue(WallE_Utilitaire.diviserCent(val) == 1.50);
		val = 9990;
		assertTrue(WallE_Utilitaire.diviserCent(val) == 99.9);
		val = 0;
		assertTrue(WallE_Utilitaire.diviserCent(val) == 0);
		val = -1798;
		assertTrue(WallE_Utilitaire.diviserCent(val) == -17.98);

	}

	@Test
	public void testArondirCentieme() {

		double val = 160.065;
		assertTrue(WallE_Utilitaire.arondirCentieme(val) == 160.06);
		val = 0.05626;
		assertTrue(WallE_Utilitaire.arondirCentieme(val) == 0.05);
		val = 657.4545454;
		assertTrue(WallE_Utilitaire.arondirCentieme(val) == 657.45);
		val = -475.4545;
		assertTrue(WallE_Utilitaire.arondirCentieme(val) == -475.45);
		val = 0.0000;
		assertTrue(WallE_Utilitaire.arondirCentieme(val) == 0.00);

	}

	/*
	 * @Test public void testVirageVitesse() { fail("Not yet implemented"); }
	 */

	@Test
	public void testForceDeuxiemeLoiNewton() {

		double masse = 500.86;
		double acc = 86.56;

		assertTrue(WallE_Utilitaire.forceDeuxiemeLoiNewton(masse, acc) == 43354.44);
		assertTrue(WallE_Utilitaire.forceDeuxiemeLoiNewton(acc, masse) == 43354.44);

		masse = 0;
		acc = 800;

		assertTrue(WallE_Utilitaire.forceDeuxiemeLoiNewton(masse, acc) == 0);
		assertTrue(WallE_Utilitaire.forceDeuxiemeLoiNewton(acc, masse) == 0);

		masse = -580510;
		acc = 98809;

		assertTrue(WallE_Utilitaire.forceDeuxiemeLoiNewton(masse, acc) == 0);

	}

	@Test
	public void testEnergieCinetique() {

		double vitesse = 40;
		double masse = 60;

		assertTrue(WallE_Utilitaire.energieCinetique(masse, vitesse) == 48000);

		vitesse = 50;
		masse = 0;

		assertTrue(WallE_Utilitaire.energieCinetique(masse, vitesse) == 0);

		vitesse = 40;
		masse = 60;
		double vitesse1 = -40;
		double masse1 = 60;

		assertTrue(WallE_Utilitaire.energieCinetique(masse, vitesse) == WallE_Utilitaire.energieCinetique(masse1,
				vitesse1));

	}

	@Test
	public void testValeurMinCapteur() {

		int v1 = 50;
		int v2 = 65;
		int v3 = 70;

		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v2, v3) == 50);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v3, v2) == 50);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v1, v3) == 50);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v3, v1) == 50);

		int a1 = 700;
		int a2 = 200;
		int a3 = 550;

		assertTrue(WallE_Utilitaire.valeurMinCapteur(a1, a2, a3) == 200);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(a1, a3, a2) == 200);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(a2, a1, a3) == 200);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(a2, a3, a1) == 200);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(a3, a2, a1) == 200);

		v1 = 0;
		v2 = -1;
		v3 = 2;

		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v2, v3) == -1);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v3, v2) == -1);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v1, v3) == -1);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v3, v1) == -1);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v3, v2, v1) == -1);

		v1 = -200;
		v2 = -300;
		v3 = 0;

		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v2, v3) == -300);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v3, v2) == -300);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v1, v3) == -300);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v2, v3, v1) == -300);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v3, v2, v1) == -300);

		v1 = 0;
		v2 = 0;
		v3 = 0;

		assertTrue(WallE_Utilitaire.valeurMinCapteur(v1, v2, v3) == 0);
		assertTrue(WallE_Utilitaire.valeurMinCapteur(v3, v2, v1) == 0);
	}

	@Test
	public void testValeurMaxCapteur() {
		int v1 = 50;
		int v2 = 65;
		int v3 = 70;

		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v1, v2, v3) == 70);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v2, v1, v3) == 70);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v3, v1, v2) == 70);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v3, v2, v1) == 70);

		int a1 = 700;
		int a2 = 200;
		int a3 = 550;

		assertTrue(WallE_Utilitaire.valeurMaxCapteur(a1, a2, a3) == 700);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(a1, a3, a2) == 700);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(a2, a3, a1) == 700);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(a3, a2, a1) == 700);

		v1 = -50;
		v2 = 60;
		v3 = -70;

		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v1, v2, v3) == 60);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v2, v1, v3) == 60);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v3, v2, v1) == 60);
		assertTrue(WallE_Utilitaire.valeurMaxCapteur(v2, v3, v1) == 60);

	}

	@Test
	public void testVitesseTOcmPs() {

		double pourcent = 100;
		double pourcent1 = 0;
		double pourcent2 = 50;
		double pourcent3 = 75;
		double pourcent4 = -1;
		double pourcent5 = -50;

		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent) == 33.1);
		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent1) == 0.0);
		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent2) == 16.55);
		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent3) == 24.82);
		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent4) == 0.33);
		assertTrue(WallE_Utilitaire.vitesseTOcmPs(pourcent5) == 16.55);

	}

}
