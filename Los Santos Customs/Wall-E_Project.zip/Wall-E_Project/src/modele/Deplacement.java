package modele;

/**
 * Énumération contenant toutes les données de déplacement pouvant être envoyées
 * au robot, soit les options Avant, Arrière, Gauche, etc.
 *
 * @author Los Santos Customs
 *
 */
public enum Deplacement {
	AVANCER("Avant", 0x01), RECULER("Arrière", 0x02), DROITE("Droite", 0x04), GAUCHE("Gauche", 0x03),
	STOP("Stop", 0x00);

	/**
	 * Tableau Statique contenant les Bytes qui seront envoyés au robot
	 */
	int commande;

	/**
	 * Mouvement fait sur le clavier (Déplacement demandé)
	 */
	String moveClavier;

	/**
	 * Définie un déplacement ou un mode possible de la voiture
	 *
	 * @param pMoveClavier   - Commande de clavier
	 * @param commandSection - Partie de la voiture à laquelle est destiné la
	 *                       commande
	 * @param command        - Action à éffectuer
	 * @param suppInfo       - Info (indiquation ou action) supplémentaire à faire
	 */
	private Deplacement(String pMoveClavier, int pCommand) {
		this.commande = pCommand;

		this.moveClavier = pMoveClavier;
	}

	/**
	 * Retourne la commande a envoyer a l'auto pour lui faire bouger
	 *
	 * @return La commande
	 */
	public int getCommande() {
		return this.commande;
	}

	/**
	 * Méthode qui retourne une action fait par le clavier de l'utilisateur, sert à
	 * faire des bindings entre certaines touches de l'app et certaines touches du
	 * clavier
	 *
	 * @return moveClavier - L'action fait sur le clavier d'ordinateur
	 */
	public String getMoveClavier() {
		return this.moveClavier;
	}

	/**
	 * Méthose qui affiche simplement les trois Bytes contenues dans cette classe,
	 * permet d'aider le programmeur au débuguage de l'application
	 */
	@Override
	public String toString() {

		return "Commande : " + this.commande + "	Direction : " + this.getMoveClavier();
	}
}
