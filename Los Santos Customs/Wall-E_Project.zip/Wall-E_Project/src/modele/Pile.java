package modele;

import java.io.Serializable;

/**
 * Cette classe permet de créer une pile d'objet dont seul le sommet est
 * accessible
 *
 * @author Los Santos Customs
 */
public class Pile implements Serializable {

	private static final long serialVersionUID = 3031983087399508019L;

	/**
	 * Pointeur pour le sommet de la pile
	 */
	private NoeudPile sommet;

	/**
	 * Conserve le nombre d'éléments dans la pile
	 */
	private int taille;

	/**
	 * Construit une pile vide
	 */
	public Pile() {
		this.sommet = null;

		this.taille = 0;
	}

	/**
	 * Retourne l'objet dépilé. Lève une exception si la pile est vide. Se sert de
	 * getPremier()
	 *
	 * @return Object l'élément dépilé
	 */
	public Object depiler() {
		Object retour = this.getPremier();

		if (!this.isEmpty()) {
			this.sommet = this.sommet.getPrecedent();

			this.taille--;
		} else
			throw new Error("Pile vide");

		return retour;
	}

	/**
	 * Empile un objet dans la pile.
	 *
	 * @param element l'élément à empiler
	 */
	public void empiler(Object element) {
		this.sommet = new NoeudPile(element, this.sommet);
		this.taille++;
	}

	/**
	 * Retourne l'objet contenu dans le noeud sur le dessus de la pile sans le
	 * dépiler Lève une exception si la pile est vide.
	 *
	 * @return Object, l'objet sur le dessus de la pile.
	 */
	public Object getPremier() {
		Object retour = null;

		if (!this.isEmpty())
			retour = this.sommet.getElement();
		else
			throw new Error("La pile est vide");

		return retour;

	}

	/**
	 * Vérifie si la pile est vide
	 *
	 * @return boolean vrai si elle est vide
	 */
	public boolean isEmpty() {
		return this.sommet == null;
	}

	/**
	 * Retourne le nombre d'éléments dans la pile
	 *
	 * @return le nombre d'éléments dans la pile
	 */
	public int size() {
		return this.taille;

	}

	/**
	 * Permet de créer une chaîne représentant les éléments qui sont dans la pile.
	 *
	 * @return le contenu de la pile sous forme de caractères
	 */
	@Override
	public String toString() {
		NoeudPile temp = this.sommet;
		// if raccourci
		String s = (this.isEmpty()) ? "vide!\n" : "";

		while (temp != null) {
			s = s + temp.getElement() + "\n";
			temp = temp.getPrecedent();
		}

		return s;
	}

	/**
	 * Vide la pile
	 */
	public void vider() {
		this.sommet = null;
		this.taille = 0;
		System.gc();
	}
}
