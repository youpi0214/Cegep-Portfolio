package modele;

import java.awt.geom.Point2D;
import java.util.List;

import communication.WifiComm;

/**
 * Cette classe contient les opération essentielles pour la gestion des calculs
 * et des structures de données
 *
 * @author Los Santos Customs
 *
 */
public class WallE_Utilitaire {

	/**
	 * Pour déterminer la distance résonnable entre le mur et la voiture sinon
	 * recule
	 */
	public static final int MARGE_DEFAULT = 8;

	/**
	 * Seconde marge d'une distance résonnable
	 */
	public static final int MARGE_LABYRINTHE = 20;

	/**
	 * index de la valeur du segment de deplacement actuel contenue dans le buffer
	 */
	public static final int INFO_DIS_SEGMENT_ACTUEL_MODULO = 3;

	/**
	 * index de la valeur d'alerte lorsque le segment de deplacement actue excède la
	 * capacité d'un Byte (atteint 255+)
	 */
	public static final int INFO_DIS_SEGMENT_MULTI = 4;

	/**
	 * index de la valeur du deplacement totale contenue dans le buffer
	 */
	public static final int INFO_DIS_PAR_TOT_MODULO = 5;

	/**
	 * index de la valeur d'alerte lorsque le deplacement totale excède la capacité
	 * d'un Byte (atteint 255+)
	 */
	public static final int INFO_DIS_PAR_TOT_MULTI = 6;

	/**
	 * Arc de rotation
	 */
	private static double CIRCONFERENCE = 80.07;

	/**
	 * Vitesse maximale
	 */
	public static final int VITESSE_MAX = 100;

	/**
	 * Vitesse minimale
	 */
	public static final int VITESSE_MIN = 0;

	/**
	 * Vitesse par défaut
	 */
	public static final int VITESSE_DEFAUT = 20;

	/**
	 * Vitesse maximale en cm/s
	 */
	public static final double VITESSE_MAX_CM_PAR_S = 33.1;

	/**
	 * Nb de capteurs sur le véhicule
	 */
	public static final int NOMBRE_CAPTEURS_ULTRASON = 3;

	/**
	 * Distance à laquelle un obstacle devient un danger
	 */
	public static final int OBSTACLE_DANGER = 15;

	/**
	 * Nb de caractères maximal dans un message à envoyer
	 */
	public static final int MESSAGE_MAX_CARACTERE = 32;

	/**
	 * Utile pour les axis x des mannettes controlant la camera, convertie les
	 * valeur des axes (qui sont en décimal --> double) en angle pour qu'il soit
	 * dans un format adequat et facile à traiter (seul les nombres entiers peuvent
	 * être envoyés transmis vers l'auto)
	 *
	 * 90-180 si la valeur de l'axis est negative et 0-90 si elle est positive
	 *
	 * @param axisValue valeur de l'axis de la manette entre -1 et 1
	 * @return la valeur de l'axis convertie en angle
	 */
	public static int ajusterAxisXManetteToAngle(double axisValue) {
		double angle = axisValue > 0 ? 90 - (axisValue * 90) : (-1 * axisValue * 90) + 90;
		return (int) Math.round(angle);
	}

	/**
	 * Utile pour les axis y des mannettes controlant la camera, convertie les
	 * valeur des axes (qui sont en décimal --> double) en angle pour qu'il soit
	 * dans un format adequat et facile à traiter (seul les nombres entiers peuvent
	 * être envoyés transmis vers l'auto)
	 *
	 * valeur retournée entre 0-180
	 *
	 * @param axisValue valeur de l'axis Y de la manette entre 0 et 1
	 * @return la valeur de l'axis convertie en angle
	 */
	public static int ajusterAxisYManetteToAngle(double axisValue) {

		return (int) Math.round(axisValue * 90) + 90;
	}

	/**
	 * Arrondir au centième
	 *
	 * @param val - La valeur à arrondir
	 * @return L'arrondissement au centième près
	 */
	public static double arondirCentieme(double val) {
		return diviserCent(multiplierCent(val));
	}

	/**
	 * Convertie la vitesse de cm/s a cm/Ms
	 *
	 * @param vitesse vitesse en cm/s
	 * @return la vitesse convertie en cm/Ms
	 */
	public static double convertVitesseToDPMilliS(double vitesse) {
		return vitesse / 1000;
	}

	/**
	 * Divise par 100
	 *
	 * @param val - La valeur à diviser
	 * @return Le quotient
	 */
	public static double diviserCent(double val) {
		return val / 100;
	}

	/**
	 * Retourne l'énergie cinétique du mobile
	 *
	 * @param pMasse   - Masse exprimé en Kg
	 * @param pVitesse - La vitesse exprimée en m/s
	 * @return L'énergie du mobile en Joules
	 */
	public static double energieCinetique(double pMasse, double pVitesse) {

		return 0.5 * pMasse * Math.pow(pVitesse, 2);
	}

	/**
	 * Deuxième Loi de Newton
	 *
	 * @param pMasse        - Masse exprimée en Kg
	 * @param pAcceleration - L'accélération en m/s^2
	 * @return La force en N
	 */
	public static double forceDeuxiemeLoiNewton(double pMasse, double pAcceleration) {

		return pMasse * pAcceleration;

	}

	/**
	 * Retourne la valeur la plus petite dans un tableau
	 *
	 * @param tab - Tableau à analyser
	 * @return L'index
	 */
	public static int minIndex(int[] tab) {
		int minValue = 0, minIndex = 0;
		for (int i = 0; i + 1 < tab.length; i++) {
			minValue = Math.min(tab[i], tab[i + 1]);
			minIndex = (minValue == tab[i + 1]) ? i + 1 : minIndex;
		}

		return minIndex;
	}

	/**
	 * Multiplie par 100
	 *
	 * @param val - La valeur à mutiplier
	 * @return Le produit
	 */
	public static int multiplierCent(double val) {
		return (int) (val * 100);
	}

	/**
	 * Créer le message
	 *
	 * @param tableauAremplir - Le tableau à remplir pour l'envoi
	 * @param listeAvider     - La liste à incrémenter dans le tableau
	 */
	public static void prepareMessage(int[] tableauAremplir, byte[] listeAvider) {
		tableauAremplir[0] = (byte) WifiComm.MESSAGE_FLAG;
		for (int i = 1; i < listeAvider.length; i++)
			tableauAremplir[i] = listeAvider[i];

	}

	/**
	 * Remplir le tableau des capteurs
	 *
	 * @param tableauAremplir - Le tableau à remplir
	 * @param objectAvider    - Les composants à imbriquer dans le tableau
	 */
	public static void remplirTab(int[] tableauAremplir, List objectAvider) {
		for (int i = 0; i < tableauAremplir.length; i++)
			tableauAremplir[i] = (int) objectAvider.get(i);

	}

	/**
	 * permet de determiner le temps de rotation de l'auto selon une vitesse et un
	 * angle voulu
	 *
	 * @param angle   angle dans lequel l'auto doit touner
	 * @param vitesse vitesse actuelle de l'auto
	 * @return temps necessaire pour touner dans l'angle donnée
	 */
	public static double tempsRotation(double angle, double vitesse) {
		double arcRotation = angle * (CIRCONFERENCE / 360);
		double tempRot = arcRotation / convertVitesseToDPMilliS(vitesse);
		return tempRot;
	}

	/**
	 * Retourne la valeur la plus grande des capteurs
	 *
	 * @param pCapteurGauche - Capteur à gauche
	 * @param pCapteurMilieu - Capteur au milieu
	 * @param pCapteurDroite - Captpeur à droite
	 * @return La plus grande valeur des capteurs
	 */
	public static int valeurMaxCapteur(int pCapteurGauche, int pCapteurMilieu, int pCapteurDroite) {

		int valMax = 0;
		valMax = Math.max(pCapteurGauche, pCapteurMilieu);
		return Math.max(valMax, pCapteurDroite);
	}

	/**
	 * Retourne la valeur la plus petite des capteurs
	 *
	 * @param pCapteurGauche - Capteur à gauche
	 * @param pCapteurMilieu - Capteur au milieu
	 * @param pCapteurDroite - Captpeur à droite
	 * @return La plus petite valeur des capteurs
	 */
	public static int valeurMinCapteur(int pCapteurGauche, int pCapteurMilieu, int pCapteurDroite) {

		int valMin = 0;
		valMin = Math.min(pCapteurGauche, pCapteurMilieu);
		return Math.min(valMin, pCapteurDroite);
	}

	/**
	 * Retourne la vitesse du virage selon les inputs de la manette
	 *
	 * @param manetteCoordo - Le vecteur de la manette
	 * @return La vitesse du virage
	 */
	public static double virageVitesse(Point2D manetteCoordo) {
		double angle = Math.atan2(Math.abs(diviserCent(multiplierCent(manetteCoordo.getY()))),
				Math.abs(diviserCent(multiplierCent(manetteCoordo.getX()))));

		return multiplierCent(Math.abs(manetteCoordo.getY()) * (angle / 90));
	}

	/**
	 * convertie la vitesse de l'auto de pourcentage à cm/s
	 *
	 * @return vitesse de l'auto (cm/s)
	 */
	public static double vitesseTOcmPs(double vitessePourCent) {
		vitessePourCent = (vitessePourCent > 100) ? vitessePourCent - 100 : vitessePourCent;

		return (vitessePourCent * VITESSE_MAX_CM_PAR_S) / 100;
	}

}
