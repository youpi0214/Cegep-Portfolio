package modele;

import static modele.Deplacement.AVANCER;
import static modele.Deplacement.DROITE;
import static modele.Deplacement.GAUCHE;

import java.awt.geom.Point2D;
import java.util.List;

import org.apache.commons.math3.util.Precision;

import javafx.application.Platform;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 * Classe Modèle de l'appplication : Permet de faire tous les calculs
 * nécessaires à l'affichage sur l'interface Graphique. Contient donc tout ce
 * qui est des mathématiques et tout le traitement de données fait par
 * l'application
 *
 * @author Los Santos Customs
 *
 */
public class ModeleWallE extends Service<Void> {

	/**
	 * Masse de la voiture en kg (Peut éventuellement changer selon les modules
	 * équipés)
	 */
	private static final double MASSE_VOITURE = 0.675;

	/**
	 * position x de l'auto (chaine de caractères affichée à l'interface visuel)
	 */
	private SimpleStringProperty posX_Lbl;

	/**
	 * position y de l'auto (chaine de caractères affichée à l'interface visuel)
	 */
	private SimpleStringProperty posY_Lbl;

	/**
	 * obstacle le plus proche (chaine de caractères affichée à l'interface visuel)
	 */
	private SimpleStringProperty ObstacleProche_Lbl;

	/**
	 * vitesse de l'auto (chaine de caractères affichée à l'interface visuel)
	 */
	private SimpleStringProperty vitesse_Lbl;

	/**
	 * énergie cinétique de l'auto (chaine de caractères affichée à l'interface
	 * visuel)
	 */
	private SimpleStringProperty energieCinetique_Lbl;

	/**
	 * Durée de l'impact
	 */
	private SimpleStringProperty tempsImpact_Lbl;

	/**
	 * L'énergie cinétique engendré
	 */
	private SimpleStringProperty cinetique_Lbl;

	/**
	 * Vitesse rectiligne de la voiture (en centimetre par seconde), les virages se
	 * font a l'arret (la voiture effectue une rotation sur elle-meme)
	 */
	private double vitesse = 0;

	/**
	 * Point dont les coordonnées représentent la position x et y du véhicule a un
	 * moment donné
	 */
	private Point2D pointPosition;

	// 0 = gauche, 1 = avant, 2 = droite, valeurs en centimetres
	/**
	 * Tableau de int contenant les valeurs envoyées par chacun des capteurs,
	 * l'index 0 correspond au capteur gauche, l'index 1 correspond au capteur avant
	 * et l'index 2 correspond au capteur de droite. Chaque valeur est donnée en
	 * centimetres.
	 *
	 */
	private int[] distanceCapteurs;

	/**
	 * Distance total parcouru
	 */
	private double DisParTotale;

	/**
	 * Distance du segment actuel
	 */
	private double disantceSegmentActuel;

	/**
	 * Distance du segment precedent
	 */
	private double distanceSegmentPrecedent;

	/**
	 * Vitesse maximale du mobile avant impact
	 */
	private double vitesseMax;

	/**
	 * Vitesse précédent la vitesse actuelle du mobile
	 */
	private double vitessePrecedent;

	/**
	 * Chornomètre le temps de collision
	 */
	private Chrono chrono;

	/**
	 * Envisage un choc
	 */
	private SimpleBooleanProperty choc;

	/**
	 * S'il est immobile
	 */
	private SimpleBooleanProperty immobile;

	/**
	 * Constructeur de la classe modele, permet d'instancier les variables.
	 */
	public ModeleWallE() {
		this.immobile = new SimpleBooleanProperty();
		this.choc = new SimpleBooleanProperty(false);
		this.ObstacleProche_Lbl = new SimpleStringProperty();
		this.tempsImpact_Lbl = new SimpleStringProperty();
		this.cinetique_Lbl = new SimpleStringProperty();

		this.vitesse = 0;
		this.vitesseMax = 0;
		this.vitesse_Lbl = new SimpleStringProperty();
		this.energieCinetique_Lbl = new SimpleStringProperty();
		this.chrono = new Chrono();

		this.pointPosition = new Point2D.Double();
		this.posX_Lbl = new SimpleStringProperty();
		this.posY_Lbl = new SimpleStringProperty();
		this.resetPos();
		this.distanceCapteurs = new int[WallE_Utilitaire.NOMBRE_CAPTEURS_ULTRASON];
	}

	/**
	 * Designe lequel des capteurs retourne la distance la plus petite
	 */
	public int capteurProcheDirection() {
		return WallE_Utilitaire.minIndex(this.getValeursCapteurs());
	}

	/**
	 * force d'impact en Newton
	 *
	 * @param temps
	 * @return
	 */
	public double collisionneur(double temps) {

		return MASSE_VOITURE * (this.vitesseMax - this.vitesse) / temps;
	}

	@Override
	protected Task<Void> createTask() {
		return new Task<Void>() {

			@Override
			protected Void call() throws Exception {

				do
					ModeleWallE.this.rafraichirCollision();
				while (!ModeleWallE.this.choc.getValue());
				return null;

			}
		};
	}

	/**
	 * Valeur en centimetre de la distance séparant la voiture et l'obstacle le plus
	 * proche devant elle.
	 *
	 * @return int : distance en centimetre séparant la voiture et l'obstacle le
	 *         plus proche devant elle
	 */
	public int distanceCapteurAvant() {

		return this.distanceCapteurs[1];
	}

	/**
	 * Valeur en centimetre de la distance séparant la voiture et l'obstacle le plus
	 * proche situé a sa droite.
	 *
	 * @return int : distance en centimetre séparant la voiture et l'obstacle le
	 *         plus proche situé a sa droite
	 */
	public int distanceCapteurDroite() {

		return this.distanceCapteurs[2];
	}

	/**
	 * Valeur en centimetre de la distance séparant la voiture et l'obstacle le plus
	 * proche situé a sa gauche.
	 *
	 * @return int : distance en centimetre séparant la voiture et l'obstacle le
	 *         plus proche situé a sa gauche
	 */
	public int distanceCapteurGauche() {

		return this.distanceCapteurs[0];
	}

	/**
	 * L'énergie cinétique de la voiture a un moment donné
	 *
	 * @return double : l'énergie cinétique de la voiture
	 */
	private double energieCinetique() {

		return WallE_Utilitaire.energieCinetique(MASSE_VOITURE, this.vitesse / 10);
	}

	public SimpleBooleanProperty getChoc() {
		return this.choc;
	}

	public Chrono getChrono() {
		return this.chrono;
	}

	public SimpleStringProperty getCinetique_Lbl() {
		return this.cinetique_Lbl;
	}

	public double getDisantceSegmentActuel() {
		return this.disantceSegmentActuel;
	}

	public double getDisParTotale() {
		return this.DisParTotale;
	}

	/**
	 * Retourne le tableau de distance des capteurs
	 *
	 * @return distanceCapteurs : le tableau de distance des capteurs
	 */
	public int[] getDistanceCapteurs() {
		return this.distanceCapteurs;
	}

	public SimpleStringProperty getObstacleProche_Lbl() {
		return this.ObstacleProche_Lbl;
	}

	/**
	 * Retourne le point indiquant la position du véhicule
	 *
	 * @return pointPosition : le point indiquant la position du véhicule
	 */
	public Point2D getPointPosition() {
		return this.pointPosition;
	}

	public SimpleStringProperty getPosX_Lbl() {
		return this.posX_Lbl;
	}

	public SimpleStringProperty getPosY_Lbl() {
		return this.posY_Lbl;
	}

	public SimpleStringProperty getTempsImpact_Lbl() {
		return this.tempsImpact_Lbl;
	}

	public int[] getValeursCapteurs() {
		return this.distanceCapteurs;
	}

	/**
	 * Retourne la vitesse actuelle du véhicule
	 *
	 * @return vitesse : la vitesse du véhicule
	 */
	public double getVitesse() {
		return this.vitesse;
	}

	public SimpleStringProperty getVitesse_Lbl() {
		return this.vitesse_Lbl;
	}

	public SimpleBooleanProperty isImmobile() {
		return this.immobile;
	}

	/**
	 * Position de la voiture selon l'axe des X (Précision au millimetre). La valeur
	 * 0.0 correspond a la position de la voiture avant l'attribution du premier
	 * objectif
	 *
	 * @return double : position X de la voiture
	 */
	public double positionX() {

		return this.pointPosition.getX();
	}

	/**
	 * Position de la voiture selon l'axe des Y (Précision au millimetre). La valeur
	 * 0.0 correspond a la position de la voiture avant l'attribution du premier
	 * objectif
	 *
	 * @return double : position Y de la voiture
	 */
	public double positionY() {

		return this.pointPosition.getY();
	}

	/**
	 * Pour une collision qu'il n'aura pas ralenti avant
	 */
	public void rafraichirCollision() {
		// Acc ou immobile
		if (!this.chrono.getEtat().equals(EtatChrono.STOPPED)
				&& (this.vitessePrecedent < this.vitesse || this.vitesse == 0)) {
			this.chrono.stop();
			System.out.println("stop (rafresh)");
		}

		// désaccélère
		else if ((!this.chrono.getEtat().equals(EtatChrono.STARTED))) {
			this.chrono.start();
			System.out.println("start (rafresh)");
		}

		this.rafraichirVitesses();
	}

	private void rafraichirVitesses() {
		// Accélère à son plus haut point ou non
		if (this.vitesseMax < this.vitesse || this.vitessePrecedent < this.vitesse)
			this.vitesseMax = this.vitesse;

		this.vitessePrecedent = this.vitesse;
	}

	/**
	 *
	 */
	public void RecommencerModele() {
		this.vitesse = 0;
		this.vitesseMax = 0;
		this.vitesse_Lbl = new SimpleStringProperty("" + this.vitesse);
		this.chrono = new Chrono();

		this.resetPos();
		this.ObstacleProche_Lbl.set("");
		this.energieCinetique_Lbl.set("");
		this.tempsImpact_Lbl.set("");
		this.cinetique_Lbl.set("");
	}

	public void resetPos() {
		this.pointPosition.setLocation(0, 0);
		this.posX_Lbl.set("" + this.positionX());
		this.posY_Lbl.set("" + this.positionY());
	}

	/**
	 * Permet de modifier l'attribut pointPosition
	 *
	 * @param point : le point indiquant la nouvelle position
	 */
	private void setPosition(double x, double y) {
		this.pointPosition.setLocation(x, y);
	}

	/**
	 * Permet de modifier l'attribut vitesse
	 *
	 * @param pVitesse : la nouvelle vitesse du véhicule
	 */
	public void setVitesse(double pVitesse) {
		this.vitesse = WallE_Utilitaire.arondirCentieme(pVitesse);
		this.vitesse_Lbl.set("" + this.vitesse);
		this.immobile.set(this.vitesse == 0);
	}

	/**
	 * Le temps en seconde avant que le véhicule percute l'obstacle le plus proche
	 * situé devant lui
	 *
	 * @return double : le temps avant la possible collision
	 */
	private double tempsAvantCollision() {

		return this.distanceCapteurAvant() / this.vitesse;
	}

	/**
	 * Permet de mettre à jour les infos de l'auto
	 *
	 * @param info distances des capteurs ultrason et distance total parcourue par
	 *             l'auto
	 */
	public void update_Cap_DisPar(List<Integer> info) {

		// update les infos des capteurs
		WallE_Utilitaire.remplirTab(this.distanceCapteurs, info);

		// update les infos de ditances (en cm) effectuées et les remets en
		// décimal au 10eme près
		this.DisParTotale = (info.get(WallE_Utilitaire.INFO_DIS_PAR_TOT_MULTI) / 10 * 255)
				+ info.get(WallE_Utilitaire.INFO_DIS_PAR_TOT_MODULO);

		this.distanceSegmentPrecedent = this.disantceSegmentActuel;

		this.disantceSegmentActuel = (info.get(WallE_Utilitaire.INFO_DIS_SEGMENT_MULTI) / 10 * 255)
				+ info.get(WallE_Utilitaire.INFO_DIS_SEGMENT_ACTUEL_MODULO);

		this.getChoc().set(this.distanceCapteurAvant() <= WallE_Utilitaire.OBSTACLE_DANGER);

		Platform.runLater(() -> {
			this.updateObstacle();
			this.cinetique_Lbl.set("" + this.energieCinetique());
			this.tempsImpact_Lbl.set("" + this.tempsAvantCollision());
		});
	}

	/**
	 * Met a jour la distance et la direction de l'obstacle affiché sur s'interface
	 * visuel
	 */
	private void updateObstacle() {

		// On décide lequel des capteurs est le plus près
		String direction = "";
		switch (this.capteurProcheDirection()) {
		case 0:
			direction = "à " + GAUCHE.getMoveClavier();
			break;
		case 1:
			direction = "en " + AVANCER.getMoveClavier();
			break;
		case 2:
			direction = "à " + DROITE.getMoveClavier();
			break;
		default:
			direction = "non identifié";
			break;
		}

		this.ObstacleProche_Lbl.set(this.getDistanceCapteurs()[this.capteurProcheDirection()] + " cm " + direction);

	}

	/**
	 * Rafraichissement de la position et de son angle
	 *
	 * @param angle     - Angle à modifier
	 * @param direction - Direction à modifier
	 */
	public void updatePosition(double angle, int direction) {

		Platform.runLater(() -> {
			this.setPosition(
					this.positionX() + Precision.round(((this.disantceSegmentActuel - this.distanceSegmentPrecedent)
							* Precision.round(Math.cos(Math.toRadians(angle)), 8)), 2),
					Precision.round(this.positionY() + ((this.disantceSegmentActuel - this.distanceSegmentPrecedent)
							* Precision.round(Math.sin(Math.toRadians(angle)), 8)), 2));

			this.posX_Lbl.set("" + this.positionX());
			this.posY_Lbl.set("" + this.positionY());
		});
	}

}
