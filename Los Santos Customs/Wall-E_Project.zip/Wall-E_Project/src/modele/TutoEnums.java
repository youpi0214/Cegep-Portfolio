package modele;

/**
 * Classe d'énumération qui fait la préparation des tutoriels pour les
 * utilisateurs qui ne comprennent pas comment fonctionne l'application
 *
 * @author Los Santos Customs
 *
 */
public enum TutoEnums {
	TUTOMENU("Ici, vous avez 4 options, \r\n" + "\r\n"
			+ "Sélectionner l’icône de Ève (Icône de gauche) vous amène au contrôle automatique du robot, ce système vous permet de laisser le robot\r se déplacer tout seul seulement en lui donnant des coordonnées (système d’auto-driving)\r\n"
			+ "\r\n"
			+ "Sélectionner l’icône de Wall-E (Icône de droite) vous amène au contrôle manuel du robot, ou vous pouvez utiliser les contrôles fournis\r avec avec l’interface visuelle ou votre propre manette pour contrôler la voiture robotique\r\n"
			+ "\r\n" + "Sélectionner l’icône Aide (En bas à gauche) vous amène ici, sur le tutoriel d’accueil\r\n" + "",
			"imageTutoMenu"),
	TUTOCOMMANDES(
			"Pour sélectionner une manette déjà supportée par le système, il suffit de cliquer sur l’option dans la colonne de gauche et le système va\r automatiquement chercher dans les périphériques si la manette en question est connectée. Si elle \rest connectée, le système va associer la manette à l’application, vous serez donc prêts à utiliser votre contrôleur.\r\n"
					+ "\r\n"
					+ "Pour sélectionner une manette qui n’est pas déjà préconfigurée dans le système, veuillez sélectionner un des périphériques dans\r la colonne qui sera générée à gauche. Ensuite, cliquez sur ‘Configurer nouvelle Manette’ et l’application\r vous demandera de mapper votre propre manette à l’application une fois toutes les questions répondues, le système va associer votre nouvelle manette à l’application et vous allez donc pouvoir contrôler le robot avec votre propre contrôleur\r\n"
					+ "\r\n"
					+ "Pour retourner, seulement cliquer sur ‘Retour’, pour revenir au dernier menu ouvert.\r\n" + "",
			"imageCommandes"),
	TUTOAUTO(
			"L’interface de contrôle automatique permet à l’utilisateur de contrôler la voiture d’une façon semi-automatique. Il faut simplement entrer \r deux coordonnées en X et en Y. \r\n"
					+ "\r\n"
					+ "Une fois que les données sont entrées, il faut simplement appuyer sur “Go” ou bien sur la touche “Enter” sur le clavier d’ordinateur\r\n"
					+ "\r\n"
					+ "L’écran noir au milieu affiche automatiquement le flux vidéo de votre voiture, si le flux vidéo ne s’affiche pas, \rvous allez recevoir un message d’erreur à l’écran. Assurez vous que la caméra soit bien connectée selon les instructions du fournisseur.\r\n"
					+ "\r\n"
					+ "En bas à droite se situe un log pour pouvoir garder en vue les bugs de l’application, importance capitale si vous êtes un développeur\r\n"
					+ "\r\n" + "En bas à gauche se trouve les informations en direct transmises par votre voiture.\r\n"
					+ "\r\n"
					+ "Le système informatique qui contrôle la voiture crée un labyrinthe virtuel basé sur ce qu’il voit dans la réalité avec \r ses multiples capteurs de distance.\r\n"
					+ "",
			"imageAuto"),
	TUTOMANUEL(
			"L’interface de contrôle manuel permet à l’utilisateur de contrôler la voiture manuellement, soit avec une manette de jeu connectée, ou\r bien avec les commandes fournies avec l’interface\r\n"
					+ "\r\n"
					+ "Pour apprendre à connecter une manette, veuillez sélectionner l’option “Tutoriel Commandes“ dans l’option “Aide”.\r\n"
					+ "\r\n"
					+ "L’écran noir au milieu affiche automatiquement le flux vidéo de votre voiture, si le flux vidéo ne s’affiche pas, vous allez \rrecevoir un message d’erreur à l’écran. Assurez vous que la caméra soit bien connectée\r selon les instructions du fournisseur.\r\n"
					+ "\r\n"
					+ "Pour contrôler la voiture, il faut simplement cliquer sur une des quatres touches, soit AVANT, GAUCHE, ARRIÈRE et DROITE.,\r Les touches w,a,s et d du clavier font également la même fonction.\r\n"
					+ "\r\n"
					+ "En bas à droite se situe un log pour pouvoir garder en vue les bugs de l’application, importance capitale si vous êtes un développeur\r\n"
					+ "\r\n" + "En bas à gauche se trouve les informations en direct transmises par votre voiture.\r\n"
					+ "",
			"imageManuel");

	/**
	 * Une string qui renvoie l'URL de l'image fournie dans le Tutoriel
	 */
	String imageString;

	/**
	 * La série de caractères qui seront affichés à l'utilisateur
	 */
	String texteTuto;

	/**
	 * Constructeur qui fait seulement affecter les valeurs reçues aux attributs de
	 * l'enumération
	 *
	 * @param texteTuto   - La série de caractères qui seront affichés à
	 *                    l'utilisateur
	 * @param imageString - Une string qui renvoie l'URL de l'image fournie dans le
	 *                    Tutoriel
	 */
	private TutoEnums(String texteTuto, String imageString) {
		this.imageString = imageString;

		this.texteTuto = texteTuto;
	}

	/**
	 * Retourne l'URL de l'image recherchée
	 *
	 * @return String - l'URL de l'image recherchée
	 */
	public String getImageString() {
		return this.imageString;
	}

	/**
	 * Retourne l'entièreté du totoriel sous forme de texte
	 *
	 * @return String - Le tutoriel à afficher
	 */
	public String getTexteTuto() {
		return this.texteTuto;
	}

}
