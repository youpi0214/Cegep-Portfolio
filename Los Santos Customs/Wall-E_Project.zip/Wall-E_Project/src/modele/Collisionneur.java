package modele;

public abstract class Collisionneur {

}
