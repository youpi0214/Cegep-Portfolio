package modele;

/**
 * Classe des états de chrono
 *
 * @author Los Santos Customs
 *
 */
public enum EtatChrono {
	STARTED, PAUSED, RESUMED, STOPPED;
}
