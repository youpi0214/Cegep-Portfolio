package modele;

import java.awt.geom.Point2D;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 * Classe mère qui est sujet au projet d'intégration. Il donne la possibilitée à
 * une entité dans une position de départ à trouver la sortie si possible, à
 * l'aide de l'algorithme de Pledge
 *
 * @author Los Santos Customs
 *
 */
public class LabyrintheDePledge extends Service<Void> {

	/**
	 * Pour empiler un objet
	 *
	 * @author Los Santos Customs
	 *
	 */
	class Coord {

		/**
		 * Position du véhicule
		 */
		private Point2D cPosition;

		/**
		 * Angle du véhicule par rapport à son origine (pointant l'axe des x
		 * initialement)
		 */
		private double cAngle;

		/**
		 * Constructeur donnant les valeurs des paranètres aux attributs
		 *
		 * @param cPosition - La position du véhicule actuelle
		 * @param cAngle    - L'angle du véhicule actuelle
		 */
		public Coord(Point2D cPosition, double cAngle) {
			this.cPosition = cPosition;
			this.cAngle = cAngle;
		}

		public double getcAngle() {
			return this.cAngle;
		}

		public Point2D getcPosition() {
			return this.cPosition;
		}
	}

	/**
	 * Numéro d'erreur en cas de faille
	 */
	public static final int AI_ERROR = 404;

	/**
	 * Valeur maximal de la boucle du Service
	 */
	private static final int TIMEOUT_MAX_VALUE = 50;

	/**
	 * Valeur pour avancer
	 */
	private static final int AVANCE = 1;

	/**
	 * Valeur pour arrêter
	 */
	private static final int STOP = 0;

	/**
	 * Valeur pour alerter le véhicule de tourner
	 */
	private static final int TOURNE1 = 3;

	/**
	 * Valeur alternative pour alerter le véhicule de tourner
	 */
	private static final int TOURNE2 = 4;

	/**
	 * Temps d'attente pour permette au système d'effectuer les calculs
	 */
	private static final int WAIT = 150;

	/**
	 * Compteur qui s'incrémente de 1 si l'entité tourne à droite et se soustrait de
	 * 1 s'il tourne à gauche. La valeur de départ est de 0.
	 */
	private int compteur = 0;

	/**
	 * La zone à atteindre
	 */
	private Point2D objectif;

	/**
	 * L'angle degrés du devant de la voiture selon le labyrinthe
	 */
	private double angle;

	/**
	 * Entité servant à lancer les alertes de commande au controleur de
	 * l'application
	 */
	private SimpleIntegerProperty avancer;

	/**
	 * Pile servant de la méthode LIFO, pour avoir la trace (pos et angle) du
	 * véhicule à chaque mouvement
	 */
	private Pile pile;

	/**
	 * Banque de données contenant les informations en temps réel de l'auto
	 */
	private ModeleWallE auto;

	/**
	 * nombre d'iteration effectués avant chaque deplacement de l'auto (un trop
	 * grand nombre signifie que la voiture ne peut effectuer aucun mouvement et est
	 * coincer. Cela enclanche l'arret de l'auto et du thread)
	 */
	private double timeoutCheck;

	/**
	 * L'angle à laquel le véhicule doit rotationner
	 */
	private double angleRotation;

	/**
	 * Constructeur donnant les valeurs de départ de chaque attribut et enclanche le
	 * début de l'algorithme
	 *
	 * @param lab - Le labyrinthe à laquel l'entité fait face
	 */
	public LabyrintheDePledge(ModeleWallE pAuto) {
		this.pile = new Pile();
		this.auto = pAuto;
		this.objectif = new Point2D.Double();
		this.avancer = new SimpleIntegerProperty(0);
		this.timeoutCheck = 0;

	}

	/**
	 * Vérifie s'il se trouve à destination
	 */

	private boolean arriveDestination() {
		return this.auto.positionX() >= this.objectif.getX() - WallE_Utilitaire.MARGE_DEFAULT
				&& this.auto.positionX() <= this.objectif.getX() + WallE_Utilitaire.MARGE_DEFAULT
				&& this.auto.positionY() >= this.objectif.getY() - WallE_Utilitaire.MARGE_DEFAULT
				&& this.auto.positionY() <= this.objectif.getY() + WallE_Utilitaire.MARGE_DEFAULT;
	}

	private void avancer(Integer a) {
		this.avancer.setValue(a);
		if (a == 0) {
			double wait = System.currentTimeMillis() + 2000;
			while (System.currentTimeMillis() <= wait) {
			}
		}
	}

	/**
	 * Empile la dernière positon
	 */
	private void changerPosition() {
		this.pile.empiler(new Coord((Point2D) this.auto.getPointPosition().clone(), this.angle));
	}

	/**
	 * Sert simplement à modifier le compteur
	 *
	 * @param a - Le nombre à additionner au compteur
	 */
	private void compteurChanger(int a) {
		this.compteur += a;
	}

	/**
	 * s'il ya de l'espace pour pouvoir tourner, regarde s'il peut atteindre ou se
	 * rapprocher de l'objectif. Pourrait être compromis s'il longe le mur trop près
	 */

	@Override
	protected Task<Void> createTask() {
		return new Task<Void>() {

			@Override
			protected Void call() throws Exception {
				// Début de l'algorithme
				LabyrintheDePledge.this.depart();
				return null;
			}
		};
	}

	/**
	 * S'occupe de faire la boucle jusqu'à ce qu'il soit à son point d'arriver ou
	 * que le compteur disjoncte (il sera alors impossible de résoudre son
	 * environnement) ou qu'il parcourt une boucle infini
	 */
	private void depart() {
		this.angle = 0;
		this.compteur = 0;
		this.timeoutCheck = 0;
		this.avancer.set(0);
		this.pile.vider();

		while (!this.arriveDestination())
			if (this.timeoutCheck < TIMEOUT_MAX_VALUE || Math.abs(this.compteur) < 10)
				this.mouvement();
			else {
				this.avancer.set(AI_ERROR);

				this.cancel();
				break;
			}

	}

	/**
	 * Si le mobile à l'espace pour rotationner, il pivotera pour constater s'il
	 * peut atteindre l'objectif. //TODO ET NON SE RAPPROCHER
	 */
	private void essayerAtteindre() {

		if (this.auto.distanceCapteurGauche() >= WallE_Utilitaire.MARGE_DEFAULT
				&& this.auto.distanceCapteurDroite() >= WallE_Utilitaire.MARGE_DEFAULT) {
			int pileSize = this.pile.size();
			this.rotation();

			if ((this.auto.distanceCapteurAvant() > Point2D.distance(this.auto.positionX(), this.auto.positionY(),
					this.objectif.getX(), this.objectif.getY())
					|| this.auto.distanceCapteurAvant() > WallE_Utilitaire.MARGE_DEFAULT))
				this.compteurChanger(-this.compteur);
			else if (pileSize == this.pile.size() - 1) {
				this.rotation(-((Coord) this.pile.depiler()).getcAngle());
				this.pile.depiler();
			}

		}
	}

	public double getAngleRotation() {
		return this.angleRotation;
	}

	public SimpleIntegerProperty getInfoMouvement() {
		return this.avancer;
	}

	/**
	 * Si le compteur est à zéro, le véhicule doit continuer devant lui jusqu'à ce
	 * qu'il atteigne un obstacle. Il tournera alors vers la droite. Advenant le cas
	 * où il ne longe plus le mur, il doit regarder s'il peut atteindre l'objectif.
	 * Advenant le cas où le compteur est différent de zéro, le véhicule doit
	 * continuer devant lui jusqu'à ce qu'il atteigne un obstacle. Il tournera alors
	 * vers la droite. Advenant le cas où il ne longe plus le mur; il doit
	 * s'arrêter, pivoter en angle droit, avancer jusqu'à ce qu'il détecte le mur
	 * étant écourté.
	 */
	private void mouvement() {

		this.essayerAtteindre();

		if (this.compteur == 0) {
			this.avancer(AVANCE);
			this.timeoutCheck = 0;
			boolean pasArrive = false, aucunChoc = false;
			while ((pasArrive = !this.arriveDestination())
					&& (aucunChoc = !this.auto.getChoc().getValue().booleanValue())) {
				this.auto.updatePosition(this.angle, AVANCE);
				double wait = System.currentTimeMillis() + WAIT;
				while (System.currentTimeMillis() <= wait) {
				}
			}
			this.avancer(STOP);

			if (!aucunChoc && pasArrive) {
				this.rotation(-90);
				this.compteurChanger(1);
			}
			this.changerPosition();
		} else {
			boolean murGauche = true;

			this.avancer(AVANCE);
			this.timeoutCheck = 0;
			while (!this.arriveDestination() && !this.auto.getChoc().getValue().booleanValue()
					&& (murGauche = this.auto.distanceCapteurGauche() < WallE_Utilitaire.MARGE_LABYRINTHE + 2)) {
				this.auto.updatePosition(this.angle, AVANCE);
				double wait = System.currentTimeMillis() + WAIT;
				while (System.currentTimeMillis() <= wait) {
				}

			}
			this.avancer(STOP);
			this.changerPosition();

			if (!murGauche) {
				this.rotation(90);
				this.compteurChanger(-1);
				this.avancer(AVANCE);
				this.timeoutCheck = 0;
				System.out.println("choc " + this.auto.getChoc().getValue().booleanValue());
				while (!this.arriveDestination() && !this.auto.getChoc().getValue().booleanValue()
						&& (murGauche = this.auto.distanceCapteurGauche() > WallE_Utilitaire.MARGE_LABYRINTHE + 2)) {
					System.out.println("esquive mur gauche");
					this.auto.updatePosition(this.angle, AVANCE);
					double wait = System.currentTimeMillis() + WAIT;
					while (System.currentTimeMillis() <= wait) {
					}

				}
				this.avancer(STOP);
				this.changerPosition();
			}

		}

	}

	/**
	 * Tourne l'auto vers l'objectif
	 */
	private void rotation() {

		double AngleVersObjectif = Math.toDegrees(
				Math.atan2(this.objectif.getY() - this.auto.positionY(), this.objectif.getX() - this.auto.positionX()));

		this.angleRotation = (AngleVersObjectif - this.angle);

		System.out.println("AngleVersObj: " + AngleVersObjectif + "  angle: " + this.angle); // TODO

		if (this.angleRotation != 0) {

			double tempsRot = System.currentTimeMillis() + WallE_Utilitaire
					.tempsRotation(Math.abs(AngleVersObjectif - this.angle), WallE_Utilitaire.VITESSE_DEFAUT);
			this.avancer((this.avancer.getValue() == TOURNE1) ? TOURNE2 : TOURNE1);
			while (System.currentTimeMillis() <= tempsRot) {

			}
			this.avancer(STOP);
			this.angle = AngleVersObjectif;
			this.changerPosition();
		}
	}

	/**
	 * Tourne l'auto avec un angle donné
	 *
	 * @param pAngle - Angle à laquel le véhicule doit rotationner
	 */
	private void rotation(double pAngle) {
		if (pAngle != 0) {
			// TODO Voir +360 mod 360
			this.angleRotation = pAngle;

			System.out.println("pAngle: " + pAngle); // TODO
			double tempsRot = System.currentTimeMillis()
					+ WallE_Utilitaire.tempsRotation(Math.abs(pAngle), WallE_Utilitaire.VITESSE_DEFAUT);

			this.avancer((this.avancer.getValue() == TOURNE1) ? TOURNE2 : TOURNE1);
			while (System.currentTimeMillis() <= tempsRot) {

			}
			this.avancer(STOP);

			this.angle += pAngle;
			this.changerPosition();
		}

	}

	/**
	 * Détermine l'objectif
	 *
	 * @param x - Coordonné sur l'abscisse
	 * @param y - Coordonné sur l'ordonné
	 */
	public void setObjectif(int x, int y) {
		this.objectif.setLocation(x, y);
	}
}
