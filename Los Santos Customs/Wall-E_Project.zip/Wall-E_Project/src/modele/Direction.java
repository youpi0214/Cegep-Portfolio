package modele;

/**
 * Classe énumération servant à déterminer l'orientation du devant de la voiture
 * dans le labyrinthe
 *
 * @author Los Santos Customs
 *
 */
public enum Direction {
	DROITE, HAUT, GAUCHE, BAS
}
