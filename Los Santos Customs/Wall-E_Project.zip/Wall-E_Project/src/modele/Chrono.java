package modele;

/**
 * Classe agissant tel un chronomètre
 *
 * @author Williams Roberge-Bolduc
 *
 */
public class Chrono {

	/**
	 * Temps au départ
	 */
	private long tempsDepart = 0;

	/**
	 * Temps à la fin
	 */
	private long tempsFin = 0;

	/**
	 * Temps au départ
	 */
	private long pauseDepart = 0;

	/**
	 * Temps à la fin
	 */
	private long pauseFin = 0;

	/**
	 * Durée du chronomètre
	 */
	private long duree = 0;

	/**
	 * État du chronomètre
	 */
	private EtatChrono etat;

	public double getDureeMillis() {
		return this.duree;
	}

	public double getDureeSec() {
		return this.getDureeMillis() / 1000;
	}

	public EtatChrono getEtat() {
		return this.etat;
	}

	/**
	 * Met en pause le chronomètre
	 */
	public void pause() {
		this.etat = EtatChrono.PAUSED;
		if (this.tempsDepart == 0)
			return;
		this.pauseDepart = System.currentTimeMillis();
	}

	/**
	 * Ne s'applique que si le chornomètre était en pause. Alors il peut continuer
	 */
	public void resume() {
		if (this.etat.equals(EtatChrono.STOPPED)) {
			this.etat = EtatChrono.RESUMED;
			if (this.tempsDepart == 0)
				return;
			if (this.pauseDepart == 0)
				return;
			this.pauseFin = System.currentTimeMillis();
			this.tempsDepart = this.tempsDepart + this.pauseFin - this.pauseDepart;
			this.tempsFin = 0;
			this.pauseDepart = 0;
			this.pauseFin = 0;
			this.duree = 0;
		}
	}

	/**
	 * Changle l'état, rend nulle les valeurs et donne comme valeur de départ le
	 * temps en millis du système
	 */
	public void start() {
		if (this.etat.equals(EtatChrono.STOPPED)) {
			this.etat = EtatChrono.STARTED;
			this.tempsDepart = System.currentTimeMillis();
			this.tempsFin = 0;
			this.pauseDepart = 0;
			this.pauseFin = 0;
			this.duree = 0;
		}
	}

	/**
	 * Arrêt du chronomètre
	 */
	public void stop() {
		if (!this.etat.equals(EtatChrono.STOPPED))
			this.etat = EtatChrono.STOPPED;
		if (this.tempsDepart == 0)
			return;
		this.tempsFin = System.currentTimeMillis();
		this.duree = (this.tempsFin - this.tempsDepart) - (this.pauseFin - this.pauseDepart);
		this.tempsDepart = 0;
		this.tempsFin = 0;
		this.pauseDepart = 0;
		this.pauseFin = 0;
	}

	@Override
	public String toString() {

		// IN : (long) temps en secondes
		// OUT : (String) temps au format texte : "1 h 26 min 3 s"

		int h = (int) (this.getDureeSec() / 3600);
		int m = (int) ((this.getDureeSec() % 3600) / 60);
		int s = (int) (this.getDureeSec() % 60);

		String r = "";

		if (h > 0)
			r += h + " h ";
		if (m > 0)
			r += m + " min ";
		if (s > 0)
			r += s + " s";
		if (h <= 0 && m <= 0 && s <= 0)
			r = "0 s";

		return r;
	}

}